<?php
require_once('/var/www/html/SuiteCRM-7.9.8/custom/modules/Accounts/vendor/autoload.php');
use GusApi\BulkReportTypes;
use GusApi\Exception\InvalidUserKeyException;           //wyjątek "błędny klucz api"
use GusApi\Exception\NotFoundException;                 //wyjątek "nie znalezniono"
use GusApi\Exception\InvalidServerResponseException;    //wyjątek "błędna odpowiedz od serwera"
use GusApi\Exception\InvalidReportTypeException;        //wyjątek "błędny typ raportu"
use GusApi\GusApi;
use GusApi\ReportTypes;
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

// BAZA DANYCH
global $db;
$results = $db->query("select nip_c from accounts_cstm as i left join accounts as k on i.id_c=k.id where k.deleted=0 and nip_c = '" .html_entity_decode($_POST["NIP_FROM_JS"]). "' ", true); //ZAPYTANIE DO BAZY DANYCH.
$row = $db->fetchByAssoc($results);  // OTRZYMANIE WYNIKU OD BAZY DANYCH

$arr_account_type = array(
    "1" => array ( //Osoba prawna(1)
        "044" => "administracja",    //  UCZELNIE
        "050" => "administracja",    //  KOŚCIÓŁ KATOLICKI
        "076" => "administracja",    //  SAMORZĄDY GOSPODARCZE I ZAWODOWE NIEWPISANE DO KRS
        "155" => "stowarzyszenie",   //  STOWARZYSZENIA 
        "116" => "spolka_akcyjna",   //  SPÓŁKI AKCYJNE
        "117" => "spolka_zoo",       //  SPÓŁKI Z OGRANICZONĄ ODPOWIEDZIALNOŚCIĄ
        "148" => "fundacja",         //  FUNDACJE
        "169" => "administracja",    //  IZBY GOSPODARCZE
        "174" => "stowarzyszenie",   //  ZWIĄZKI PRACODAWCÓW
        "403" => "administracja",    //  WSPÓLNOTY SAMORZĄDOWE
        "428" => "administracja",    //  PAŃSTWOWE JEDNOSTKI ORGANIZACYJNE
        "429" => "administracja",    //  GMINNE SAMORZĄDOWE JEDNOSTKI ORGANIZACYJNE
        
    ),

    "2" => array ( // Jednostka organizacyjna niemająca osobowości prawnej(2)
        "019" => "spolka_cywilna",      //  SPÓŁKI CYWILNE PROWADZĄCE DZIAŁALNOŚĆ NA PODSTAWIE UMOWY ZAWARTEJ ZGODNIE Z KODEKSEM CYWILNYM
        "080" => "administracja",       //  PRZEDSTAWICIELSTWA ZAGRANICZNE
        "115" => "spolka_partnerska",   //  SPÓŁKI PARTNERSKIE
        "118" => "spolka_jawna",        //  SPÓŁKI JAWNE
        "120" => "spolka_komandytowa",  //  SPÓŁKI KOMANDYTOWE
        "121" => "spolka_koman_akcyj",  //  SPÓŁKI KOMANDYTOWO - AKCYJNE
        "179" => "spolka_zoo",          //  ODDZIAŁY ZAGRANICZNYCH PRZEDSIĘBIORCÓW 
        "401" => "administracja",       //  ORGANY WŁADZY, ADMINISTRACJI RZĄDOWEJ
        "429" => "administracja",       //  GMINNE SAMORZĄDOWE JEDNOSTKI ORGANIZACYJNE
        "431" => "administracja",       //  WOJEWÓDZKIE SAMORZĄDOWE JEDNOSTKI ORGANIZACYJNE
        ),

    "9" => array ( //osoba fizyczna prowadzącą działalność gospodarczą (9).
        "099" => "dzialalnosc_gospodarcza",     // OSOBY FIZYCZNE PROWADZĄCE DZIAŁALNOŚĆ GOSPODARCZĄ
    )
); // TABLICA FORMY DZIAŁALNOŚCI

if($row){ // $row JEST TRUE
    $message_box["status"] = 1;
    $message_box["message"] = "Istnieje już kontrahent w bazie z identycznym numerem NIP.";
    echo json_encode($message_box);
} else { // W PRZECIWNYM RAZIE FALSE
    // LOGOWANIE
    $gus = new GusApi("f8a8222ca4244368b3df");
    $gus->login();
    try {
        $gusReport = $gus->getByNip(html_entity_decode($_POST["NIP_FROM_JS"]))[0];                       // Wyszukiwanie kontkretnego nipa
        $reportType = ReportTypes::REPORT_PUBLIC_LAW;               // Ustawienie typ podmiotu
        $fullReport = $gus->getFullReport($gusReport, $reportType); // Pobranie dane konkretnego nipa z podmiotem
        //POBRANIE RAPORTU
        if( $fullReport[0][praw_podstawowaFormaPrawna_Symbol] == NULL && $fullReport[0][praw_szczegolnaFormaPrawna_Symbol] == NULL ){ // FORMA DZIAŁALNOŚĆ DZIAŁALNOŚĆ GOSPODARCZA
            $reportType = ReportTypes::REPORT_ACTIVITY_PHYSIC_CEIDG;
            $fullReport = $gus->getFullReport($gusReport, $reportType);
            $nazwa = $gusReport->getName();                                                                                 //  NAZWA
            $numerTelefonu = $fullReport[0][fiz_numerTelefonu];                                                             //  NUMER TELEFONU
            $numerFaksu = $fullReport[0][fiz_numerFaksu];                                                                   //  NUMER FAKSU
            $ulica = $gusReport->getStreet();                                                                               //  ULICA
            $numerNieruchomosci = $gusReport->getPropertyNumber();                                                          //  NUMER NIERUCHOMOSCI
            $adres = $ulica." ".$numerNieruchomosci;                                                                        //  ADRES
            $miasto = $gusReport->getCity();                                                                                //  MIASTO                                                                                                         
            $wojewodztwo = $gusReport->getProvince();                                                                       //  WOJEWODZTWO
            $kraj = $fullReport[0][fiz_adSiedzKraj_Nazwa];                                                                  //  KRAJ
            $kodPocztowy = $gusReport->getZipCode();                                                                        //  KOD POCZTOWY
            $numerMieszkania = $gusReport->getApartmentNumber();                                                            //  NUMER MIESZKANIA
            $adresStronyinternetowej = $fullReport[0][fiz_adresStronyinternetowej];                                         //  ADRES STRONY INTERNETOWEJ
            $dataPowstania = $fullReport[0][fiz_dataPowstania];                                                             //  DATA POWSTANIA
            $dataRozpoczeciaDzialalnosci = $fullReport[0][fiz_dataRozpoczeciaDzialalnosci];                                 //  DATA ROZPOCZĘCIA DZIAŁANOŚCI
            $dataZakonczeniaDzialalnosci = $fullReport[0][fiz_dataZakonczeniaDzialalnosci];                                 //  DATA ZAKONCZENIA DZIAŁAŁNOSCI
            $dataZawieszeniaDzialalnosci = $fullReport[0][fiz_dataZawieszeniaDzialalnosci];                                 //  DATA ZAWIESZENIA DZIAŁAŁNOSCI
            $dataWznowieniaDzialalnosci = $fullReport[0][fiz_dataWznowieniaDzialalnosci];                                   //  DATA WZNOWIENIA DZIAŁAŁNOSCI
            $dataOrzeczeniaOUpadlosci = $fullReport[0][fiz_dataOrzeczeniaOUpadlosci];                                       //  DATA ORZECZENIA O UPADŁOSCI
            $dataZakonczeniaPostepowaniaUpadlosciowego = $fullReport[0][fiz_dataZakonczeniaPostepowaniaUpadlosciowego];     //  DATA ZAKONCZENIA POSTĘPOWANIA UPADŁOSCIOWEGO

            $reportType = ReportTypes::REPORT_ACTIVITY_PHYSIC_PERSON;
            $fullReport = $gus->getFullReport($gusReport, $reportType);
            $podstawowaFormaPrawna_Symbol = $fullReport[0][fiz_podstawowaFormaPrawna_Symbol];
            $szczegolnaFormaPrawna_Symbol = $fullReport[0][fiz_szczegolnaFormaPrawna_Symbol]; 
        } else { // RESZTA FORMA DZIAŁALNOŚCI 
            $nazwa = $gusReport->getName();                                                                                 //  NAZWA
            $numerTelefonu = $fullReport[0][praw_numerTelefonu];                                                            //  NUMER TELEFONU
            $numerFaksu = $fullReport[0][praw_numerFaksu];                                                                  //  NUMER FAKSU
            $podstawowaFormaPrawna_Symbol = $fullReport[0][praw_podstawowaFormaPrawna_Symbol];                              //  PODSTATOWA FORMA PRAWNA SYMBOL
            $szczegolnaFormaPrawna_Symbol = $fullReport[0][praw_szczegolnaFormaPrawna_Symbol];                              //  SZCZEGOLNA FORMA PRAWNA SYMBOL
            $formaDzialalnosc = $arr_account_type[$podstawowaFormaPrawna_Symbol][$szczegolnaFormaPrawna_Symbol];            //  FORMA DZIAŁALNOŚĆI
            $ulica = $gusReport->getStreet();                                                                               //  ULICA
            $numerNieruchomosci = $gusReport->getPropertyNumber();                                                          //  NUMER NIERUCHOMOSCI
            $adres = $ulica." ".$numerNieruchomosci;                                                                        //  ADRES
            $miasto = $gusReport->getCity();                                                                                //  MIASTO                                                                                                         
            $wojewodztwo = $gusReport->getProvince();                                                                       //  WOJEWODZTWO
            $kraj = $fullReport[0][praw_adSiedzKraj_Nazwa];                                                                 //  KRAJ
            $kodPocztowy = $gusReport->getZipCode();                                                                        //  KOD POCZTOWY
            $numerMieszkania = $gusReport->getApartmentNumber();                                                            //  NUMER MIESZKANIA
            $adresStronyinternetowej = $fullReport[0][praw_adresStronyinternetowej];                                        //  ADRES STRONY INTERNETOWEJ
            $dataPowstania = $fullReport[0][praw_dataPowstania];                                                            //  DATA POWSTANIA
            $dataRozpoczeciaDzialalnosci = $fullReport[0][praw_dataRozpoczeciaDzialalnosci];                                //  DATA ROZPOCZĘCIA DZIAŁANOŚCI
            $dataZakonczeniaDzialalnosci = $fullReport[0][praw_dataZakonczeniaDzialalnosci];                                //  DATA ZAKONCZENIA DZIAŁAŁNOSCI
            $dataZawieszeniaDzialalnosci = $fullReport[0][praw_dataZawieszeniaDzialalnosci];                                //  DATA ZAWIESZENIA DZIAŁAŁNOSCI
            $dataWznowieniaDzialalnosci = $fullReport[0][praw_dataWznowieniaDzialalnosci];                                  //  DATA WZNOWIENIA DZIAŁAŁNOSCI
            $dataOrzeczeniaOUpadlosci = $fullReport[0][praw_dataOrzeczeniaOUpadlosci];                                      //  DATA ORZECZENIA O UPADŁOSCI
            $dataZakonczeniaPostepowaniaUpadlosciowego = $fullReport[0][praw_dataZakonczeniaPostepowaniaUpadlosciowego];    //  DATA ZAKONCZENIA POSTĘPOWANIA UPADŁOSCIOWEGO
        }
        $formaDzialalnosc = $arr_account_type[$podstawowaFormaPrawna_Symbol][$szczegolnaFormaPrawna_Symbol];
        
        $gus->logout(); //WYLOGOWANIE
        
        //PRZYPISANIE WARTOSCI OKNA SUITECRM
        $data_from_GUS = array();
        // NAZWA
        if($nazwa != ""){ 
            $data_from_GUS["nazwa"] = $nazwa;
        } else {
            $data_from_GUS["nazwa"] = "EMPTY_DATA_FROM_GUS";
        }
        // TELEFON
        if($numerTelefonu != ""){ 
            $data_from_GUS["numerTelefonu"] = $numerTelefonu;
        } else {
            $data_from_GUS["numerTelefonu"] = "EMPTY_DATA_FROM_GUS";
        }
        // FAKS
        if($numerFaksu != ""){ 
            $data_from_GUS["numerFaksu"] = $numerFaksu;
        } else {
            $data_from_GUS["numerFaksu"] = "EMPTY_DATA_FROM_GUS";
        }
        // FORMA DZIAŁALNOŚCI
        if($formaDzialalnosc != ""){ 
            $data_from_GUS["formaDzialalnosc"] = $formaDzialalnosc;
        } else {
            $data_from_GUS["formaDzialalnosc"] = "EMPTY_DATA_FROM_GUS";
        }
        // ADRES
        if($adres != ""){ 
            $data_from_GUS["adres"] = $adres;
        } else {
            $data_from_GUS["adres"] = "EMPTY_DATA_FROM_GUS";
        }
        // MIASTO
        if($miasto != ""){ 
            $data_from_GUS["miasto"] = $miasto;
        } else {
            $data_from_GUS["miasto"] = "EMPTY_DATA_FROM_GUS";
        }
        // WOJEWÓDZTWO
        if($wojewodztwo != ""){ 
            $data_from_GUS["wojewodztwo"] = $wojewodztwo;
        } else {
            $data_from_GUS["wojewodztwo"] = "EMPTY_DATA_FROM_GUS";
        }
        // KOD POCZTOWY
        if($kodPocztowy != ""){ 
            $data_from_GUS["kodPocztowy"] = $kodPocztowy;
        } else {
            $data_from_GUS["kodPocztowy"] = "EMPTY_DATA_FROM_GUS";
        }
        // KRAJ
        if($kraj != ""){ 
            $data_from_GUS["kraj"] = $kraj;
        } else {
            $data_from_GUS["kraj"] = "EMPTY_DATA_FROM_GUS";
        }
        // NR NIERUCHOMOŚCI
        if($numerNieruchomosci != ""){ 
            $data_from_GUS["numerNieruchomosci"] = $numerNieruchomosci;
        } else {
            $data_from_GUS["numerNieruchomosci"] = "EMPTY_DATA_FROM_GUS";
        }
        // NR MIESZKANIA
        if($numerMieszkania != ""){ 
            $data_from_GUS["numerMieszkania"] = $numerMieszkania;
        } else {
            $data_from_GUS["numerMieszkania"] = "EMPTY_DATA_FROM_GUS";
        }
        // WEBSITE
        if($adresStronyinternetowej != ""){ 
            $data_from_GUS["website"] = $adresStronyinternetowej;
        } else {
            $data_from_GUS["website"] = "EMPTY_DATA_FROM_GUS";
        }
        // DATA POWSTANIA
        if($dataPowstania != ""){ 
            $data_from_GUS["dataPowstania"] = $dataPowstania;
        } else {
            $data_from_GUS["dataPowstania"] = "EMPTY_DATA_FROM_GUS";
        }
        // DATA ROZPOCZĘCIA DZIAŁALNOŚCI
        if($dataRozpoczeciaDzialalnosci != ""){ 
            $data_from_GUS["dataRozpoczeciaDzialalnosci"] = $dataRozpoczeciaDzialalnosci;
        } else {
            $data_from_GUS["dataRozpoczeciaDzialalnosci"] = "EMPTY_DATA_FROM_GUS";
        }
        // DATA ZAKOŃCZENIA DZIAŁALNOŚCI
        if($dataZakonczeniaDzialalnosci != ""){ 
            $data_from_GUS["dataZakonczeniaDzialalnosci"] = $dataZakonczeniaDzialalnosci;
        } else {
            $data_from_GUS["dataZakonczeniaDzialalnosci"] = "EMPTY_DATA_FROM_GUS";
        }
        // DATA WZNOWIENIA DZIAŁALNOŚCI
        if($dataWznowieniaDzialalnosci != ""){ 
            $data_from_GUS["dataWznowieniaDzialalnosci"] = $dataWznowieniaDzialalnosci;
        } else {
            $data_from_GUS["dataWznowieniaDzialalnosci"] = "EMPTY_DATA_FROM_GUS";
        }
        // DATA ZAWIESZENIA DZIAŁALNOŚCI
        if($dataZawieszeniaDzialalnosci != ""){ 
            $data_from_GUS["dataZawieszeniaDzialalnosci"] = $dataZawieszeniaDzialalnosci;
        } else {
            $data_from_GUS["dataZawieszeniaDzialalnosci"] = "EMPTY_DATA_FROM_GUS";
        }
        // DATA ORZECZENIA O UPADŁOŚCI
        if($dataOrzeczeniaOUpadlosci != ""){ 
            $data_from_GUS["dataOrzeczeniaOUpadlosci"] = $dataOrzeczeniaOUpadlosci;
        } else {
            $data_from_GUS["dataOrzeczeniaOUpadlosci"] = "EMPTY_DATA_FROM_GUS";
        }
        // DATA ZAKOŃCZENIA POSTĘPOWANIA UPADŁOSCIOWEGO
        if($dataZakonczeniaPostepowaniaUpadlosciowego != ""){ 
            $data_from_GUS["dataZakonczeniaPostepowaniaUpadlosciowego"] = $dataZakonczeniaPostepowaniaUpadlosciowego;
        } else {
            $data_from_GUS["dataZakonczeniaPostepowaniaUpadlosciowego"] = "EMPTY_DATA_FROM_GUS";
        }
        $message_box["dane_od_gus"] = $data_from_GUS;
        $message_box["status"] = 0;
        echo json_encode($message_box);
    } catch (InvalidUserKeyException $e) {
        $message_box["status"] = 1;
        $message_box["message"] = "Błąd połaczenia z bazą REGON, błędny klucz";
        echo json_encode($message_box);
    } catch (NotFoundException $e) {
        $message_box["status"] = 1;
        $message_box["message"] = "Nie znaleziono podmiotu Bazie Internetowej Regon, zazwyczaj oznacza to wprowadzenie błędnego NIPu.";
        echo json_encode($message_box);
    } catch (InvalidServerResponseException $e) {
        $message_box["status"] = 1;
        $message_box["message"] = "Błąd połączenia z bazą REGON, serwer nie odpowiada lub nie działa. Spróbuj później.";
        echo json_encode($message_box);
    } catch (InvalidReportTypeException $e) {
        $message_box["status"] = 1;
        $message_box["message"] = "Nie poprawny typ raportu!";
        echo json_encode($message_box);
    }
}?>
