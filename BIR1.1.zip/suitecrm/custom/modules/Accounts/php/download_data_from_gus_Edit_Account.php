<?php 

require_once('/var/www/html/SuiteCRM-7.9.8/custom/modules/Accounts/vendor/autoload.php');

use GusApi\BulkReportTypes;
use GusApi\Exception\InvalidUserKeyException;           //wyjątek "błędny klucz api"
use GusApi\Exception\NotFoundException;                 //wyjątek "nie znalezniono"
use GusApi\Exception\InvalidServerResponseException;    //wyjątek "błędna odpowiedz od serwera"
use GusApi\Exception\InvalidReportTypeException;        //wyjątek "błędny typ raportu"
use GusApi\GusApi;
use GusApi\ReportTypes;

// BAZA DANYCH (DOSTĘP,ZAPYTANIE,ZNAJDOWANIE)
global $db; // UZYSKIWANIE DOSTĘP DO BAZY DANYCH SUITECRM
$results = $db->query( "select nip_c from accounts_cstm as i left join accounts as k on i.id_c=k.id where k.deleted=0 and nip_c = '" .html_entity_decode($_POST["NIP_FROM_JS"]). "' " , true); // ROBI ZAPYTANIE DO BAZY DANYCH
$row = $db->fetchByAssoc($results);  // OTRZYMANIE WYNIKU,ODPOWIEDZI OD BAZY DANYCH

$arr_account_type = array(       
    "1" => array ( //Osoba prawna(1)
        "044" => "administracja",    //  UCZELNIE
        "050" => "administracja",    //  KOŚCIÓŁ KATOLICKI
        "076" => "administracja",    //  SAMORZĄDY GOSPODARCZE I ZAWODOWE NIEWPISANE DO KRS
        "155" => "stowarzyszenie",   //  STOWARZYSZENIA 
        "116" => "spolka_akcyjna",   //  SPÓŁKI AKCYJNE
        "117" => "spolka_zoo",       //  SPÓŁKI Z OGRANICZONĄ ODPOWIEDZIALNOŚCIĄ
        "148" => "fundacja",         //  FUNDACJE
        "169" => "administracja",    //  IZBY GOSPODARCZE
        "174" => "stowarzyszenie",   //  ZWIĄZKI PRACODAWCÓW
        "403" => "administracja",    //  WSPÓLNOTY SAMORZĄDOWE
        "428" => "administracja",    //  PAŃSTWOWE JEDNOSTKI ORGANIZACYJNE
        "429" => "administracja",    //  GMINNE SAMORZĄDOWE JEDNOSTKI ORGANIZACYJNE
        
    ),

    "2" => array ( // Jednostka organizacyjna niemająca osobowości prawnej(2)
        "019" => "spolka_cywilna",      //  SPÓŁKI CYWILNE PROWADZĄCE DZIAŁALNOŚĆ NA PODSTAWIE UMOWY ZAWARTEJ ZGODNIE Z KODEKSEM CYWILNYM
        "080" => "administracja",       //  PRZEDSTAWICIELSTWA ZAGRANICZNE
        "115" => "spolka_partnerska",   //  SPÓŁKI PARTNERSKIE
        "118" => "spolka_jawna",        //  SPÓŁKI JAWNE
        "120" => "spolka_komandytowa",  //  SPÓŁKI KOMANDYTOWE
        "121" => "spolka_koman_akcyj",  //  SPÓŁKI KOMANDYTOWO - AKCYJNE
        "179" => "spolka_zoo",          //  ODDZIAŁY ZAGRANICZNYCH PRZEDSIĘBIORCÓW 
        "401" => "administracja",       //  ORGANY WŁADZY, ADMINISTRACJI RZĄDOWEJ
        "429" => "administracja",       //  GMINNE SAMORZĄDOWE JEDNOSTKI ORGANIZACYJNE
        "431" => "administracja",       //  WOJEWÓDZKIE SAMORZĄDOWE JEDNOSTKI ORGANIZACYJNE
        ),

    "9" => array ( //osoba fizyczna prowadzącą działalność gospodarczą (9).
        "099" => "dzialalnosc_gospodarcza",     // OSOBY FIZYCZNE PROWADZĄCE DZIAŁALNOŚĆ GOSPODARCZĄ
    )
); // TABLICA FORMY DZIALAŁNOŚCI

if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

$bean = BeanFactory::getBean('Accounts', $_POST["RECORD_ID_FROM_JS"]); // WYSZUKIWANIE KONTREKTNEJ REKORDU 

$message_box["RECORD_NIP_FROM_PHP"] = $bean->nip_c; 

if( $bean->nip_c == html_entity_decode($_POST["NIP_FROM_JS"]) ){ // REKORD MA TAKI SAM NIP JAK POLE DANYCH NIP 
    // LOGOWANIE
    $gus = new GusApi("f8a8222ca4244368b3df");
    $gus->login();
    
    try {
        $gusReport = $gus->getByNip(html_entity_decode($_POST["NIP_FROM_JS"]))[0];  // Wyszukiwanie kontkraetnego nipa
        $reportType = ReportTypes::REPORT_PUBLIC_LAW;                               // Przypisanie typ podmiotu
        $fullReport = $gus->getFullReport($gusReport, $reportType);                 // Pobranie dane konkretnego nipa z podmiotem

        //POBRANIE RAPORTU
        if( $fullReport[0][praw_podstawowaFormaPrawna_Symbol] == NULL && $fullReport[0][praw_szczegolnaFormaPrawna_Symbol] == NULL ){
            $reportType = ReportTypes::REPORT_ACTIVITY_PHYSIC_CEIDG;
            $fullReport = $gus->getFullReport($gusReport, $reportType);
            $nazwa = $gusReport->getName();                                                                                 //  NAZWA
            $numerTelefonu = $fullReport[0][fiz_numerTelefonu];                                                            //  NUMER TELEFONU
            $numerFaksu = $fullReport[0][fiz_numerFaksu];                                                                  //  NUMER FAKSU
            $ulica = $gusReport->getStreet();                                                                               //  ULICA
            $numerNieruchomosci = $gusReport->getPropertyNumber();                                                          //  NUMER NIERUCHOMOSCI
            $adres = $ulica." ".$numerNieruchomosci;                                                                        //  ADRES
            $miasto = $gusReport->getCity();                                                                                //  MIASTO                                                                                                         
            $wojewodztwo = $gusReport->getProvince();                                                                       //  WOJEWODZTWO
            $kraj = $fullReport[0][fiz_adSiedzKraj_Nazwa];                                                                 //  KRAJ
            $kodPocztowy = $gusReport->getZipCode();                                                                        //  KOD POCZTOWY
            $numerMieszkania = $gusReport->getApartmentNumber();                                                            //  NUMER MIESZKANIA
            $adresStronyinternetowej = $fullReport[0][fiz_adresStronyinternetowej];                                        //  ADRES STRONY INTERNETOWEJ
            $dataPowstania = $fullReport[0][fiz_dataPowstania];                                                            //  DATA POWSTANIA
            $dataRozpoczeciaDzialalnosci = $fullReport[0][fiz_dataRozpoczeciaDzialalnosci];                                //  DATA ROZPOCZĘCIA DZIAŁANOŚCI
            $dataZakonczeniaDzialalnosci = $fullReport[0][fiz_dataZakonczeniaDzialalnosci];                                //  DATA ZAKONCZENIA DZIAŁAŁNOSCI
            $dataZawieszeniaDzialalnosci = $fullReport[0][fiz_dataZawieszeniaDzialalnosci];                                //  DATA ZAWIESZENIA DZIAŁAŁNOSCI
            $dataWznowieniaDzialalnosci = $fullReport[0][fiz_dataWznowieniaDzialalnosci];                                  //  DATA WZNOWIENIA DZIAŁAŁNOSCI
            $dataOrzeczeniaOUpadlosci = $fullReport[0][fiz_dataOrzeczeniaOUpadlosci];                                      //  DATA ORZECZENIA O UPADŁOSCI
            $dataZakonczeniaPostepowaniaUpadlosciowego = $fullReport[0][fiz_dataZakonczeniaPostepowaniaUpadlosciowego];    //  DATA ZAKONCZENIA POSTĘPOWANIA UPADŁOSCIOWEGO
            $dataZaistnieniaZmiany = $fullReport[0][fiz_dataZaistnieniaZmiany];                                            //  DATA ZAISTNIENIA ZMIANY
            $nip = $fullReport[0][fiz_nip];

            $reportType = ReportTypes::REPORT_ACTIVITY_PHYSIC_PERSON;
            $fullReport = $gus->getFullReport($gusReport, $reportType);
            $podstawowaFormaPrawna_Symbol = $fullReport[0][fiz_podstawowaFormaPrawna_Symbol];
            $szczegolnaFormaPrawna_Symbol = $fullReport[0][fiz_szczegolnaFormaPrawna_Symbol]; 
            $formaDzialalnosc = $arr_account_type[$podstawowaFormaPrawna_Symbol][$szczegolnaFormaPrawna_Symbol];            //  FORMA DZIAŁALNOŚĆI

        } else {
            $nazwa = $gusReport->getName();                                                                                 //  NAZWA
            $numerTelefonu = $fullReport[0][praw_numerTelefonu];                                                            //  NUMER TELEFONU
            $numerFaksu = $fullReport[0][praw_numerFaksu];                                                                  //  NUMER FAKSU
            $podstawowaFormaPrawna_Symbol = $fullReport[0][praw_podstawowaFormaPrawna_Symbol];                              //  PODSTATOWA FORMA PRAWNA SYMBOL
            $szczegolnaFormaPrawna_Symbol = $fullReport[0][praw_szczegolnaFormaPrawna_Symbol];                              //  SZCZEGOLNA FORMA PRAWNA SYMBOL
            $formaDzialalnosc = $arr_account_type[$podstawowaFormaPrawna_Symbol][$szczegolnaFormaPrawna_Symbol];            //  FORMA DZIAŁALNOŚĆI
            $ulica = $gusReport->getStreet();                                                                               //  ULICA
            $numerNieruchomosci = $gusReport->getPropertyNumber();                                                          //  NUMER NIERUCHOMOSCI
            $adres = $ulica." ".$numerNieruchomosci;                                                                        //  ADRES
            $miasto = $gusReport->getCity();                                                                                //  MIASTO                                                                                                         
            $wojewodztwo = $gusReport->getProvince();                                                                       //  WOJEWODZTWO
            $kraj = $fullReport[0][praw_adSiedzKraj_Nazwa];                                                                 //  KRAJ
            $kodPocztowy = $gusReport->getZipCode();                                                                        //  KOD POCZTOWY
            $numerMieszkania = $gusReport->getApartmentNumber();                                                            //  NUMER MIESZKANIA
            $adresStronyinternetowej = $fullReport[0][praw_adresStronyinternetowej];                                        //  ADRES STRONY INTERNETOWEJ
            $dataPowstania = $fullReport[0][praw_dataPowstania];                                                            //  DATA POWSTANIA
            $dataRozpoczeciaDzialalnosci = $fullReport[0][praw_dataRozpoczeciaDzialalnosci];                                //  DATA ROZPOCZĘCIA DZIAŁANOŚCI
            $dataZakonczeniaDzialalnosci = $fullReport[0][praw_dataZakonczeniaDzialalnosci];                                //  DATA ZAKONCZENIA DZIAŁAŁNOSCI
            $dataZawieszeniaDzialalnosci = $fullReport[0][praw_dataZawieszeniaDzialalnosci];                                //  DATA ZAWIESZENIA DZIAŁAŁNOSCI
            $dataWznowieniaDzialalnosci = $fullReport[0][praw_dataWznowieniaDzialalnosci];                                  //  DATA WZNOWIENIA DZIAŁAŁNOSCI
            $dataOrzeczeniaOUpadlosci = $fullReport[0][praw_dataOrzeczeniaOUpadlosci];                                      //  DATA ORZECZENIA O UPADŁOSCI
            $dataZakonczeniaPostepowaniaUpadlosciowego = $fullReport[0][praw_dataZakonczeniaPostepowaniaUpadlosciowego];    //  DATA ZAKONCZENIA POSTĘPOWANIA UPADŁOSCIOWEGO
            $dataZaistnieniaZmiany = $fullReport[0][praw_dataZaistnieniaZmiany];                                            //  DATA ZAISTNIENIA ZMIANY
            $nip = $fullReport[0][praw_nip];
        }
        $formaDzialalnosc = $arr_account_type[$podstawowaFormaPrawna_Symbol][$szczegolnaFormaPrawna_Symbol];
        //--------------------------------------------------------------------------------------------------------------||
        $gus->logout(); //WYLOGOWANIE

        $elements = 0;
        if ( html_entity_decode($_POST["NAZWA_FROM_JS"]) != "EMPTY_FIELD" ) $elements++;
        if ( html_entity_decode($_POST["TELEFON_FROM_JS"]) != "EMPTY_FIELD" ) $elements++;
        if ( html_entity_decode($_POST["FAKS_FROM_JS"]) != "EMPTY_FIELD" ) $elements++;
        if ( html_entity_decode($_POST["FORMA_DZIALALNOSC_FROM_JS"]) != "EMPTY_FIELD" ) $elements++;
        if ( html_entity_decode($_POST["ADRES_FROM_JS"]) != "EMPTY_FIELD" ) $elements++;
        if ( html_entity_decode($_POST["MIASTO_FROM_JS"]) != "EMPTY_FIELD" ) $elements++;
        if ( html_entity_decode($_POST["WOJEWODZTWO_FROM_JS"]) != "EMPTY_FIELD" ) $elements++;
        if ( html_entity_decode($_POST["KOD_POCZTOWY_FROM_JS"]) != "EMPTY_FIELD" ) $elements++;
        if ( html_entity_decode($_POST["KRAJ_FROM_JS"]) != "EMPTY_FIELD" ) $elements++;
        if ( html_entity_decode($_POST["NR_NIERUCHOMOSCI_FROM_JS"]) != "EMPTY_FIELD" ) $elements++;
        if ( html_entity_decode($_POST["NR_MIESZKANIA_FROM_JS"]) != "EMPTY_FIELD" ) $elements++;
        if ( html_entity_decode($_POST["WEBSITE_FROM_JS"]) != "EMPTY_FIELD" ) $elements++;
        if ( html_entity_decode($_POST["DATA_POWSTANIA_FROM_JS"]) != "EMPTY_FIELD" ) $elements++;
        if ( html_entity_decode($_POST["DATA_ROZPOCZECIA_DZIALALNOSCI_FROM_JS"]) != "EMPTY_FIELD" ) $elements++;
        if ( html_entity_decode($_POST["DATA_ZAKONCZENIA_DZIALALNOSCI_FROM_JS"]) != "EMPTY_FIELD" ) $elements++;
        if ( html_entity_decode($_POST["DATA_WZNOWIENIA_DZIALALNOSCI_FROM_JS"]) != "EMPTY_FIELD" ) $elements++;
        if ( html_entity_decode($_POST["DATA_ZAWIESZENIA_DZIALALNOSCI_FROM_JS"]) != "EMPTY_FIELD" ) $elements++;
        if ( html_entity_decode($_POST["DATA_ORZECZENIA_O_UPADLOSCI_FROM_JS"]) != "EMPTY_FIELD" ) $elements++;
        if ( html_entity_decode($_POST["DATA_ZAKONCZENIA_POSTEPOWANIA_UPADLOSCIOWEGO_FROM_JS"]) != "EMPTY_FIELD" ) $elements++;
        
        $data_from_GUS = array();
        
        $elements_data  = array();
        $num = 0;
        // 1 - istnieje dane
        // 2 - puste dane
        // 3 - takie same dane
        
        if ( html_entity_decode($_POST["NAZWA_FROM_JS"]) != "EMPTY_FIELD" ){
            if($nazwa != ""){ // NAZWA 
                
                    if($nazwa != html_entity_decode($_POST["NAZWA_FROM_JS"])){
                        $data_from_GUS["nazwa"] = $nazwa;
                        $elements_data[$num] = 1;
                        $num++;
                    } else {
                        $data_from_GUS["nazwa"] = "SAME_DATA";
                        $elements_data[$num] = 3;
                        $num++;
                    }
            } else {
                $data_from_GUS["nazwa"] = "EMPTY_DATA_FROM_GUS";
                $elements_data[$num] = 2;
                $num++;
            }
        }
        if ( html_entity_decode($_POST["TELEFON_FROM_JS"]) != "EMPTY_FIELD" ){
            if($numerTelefonu != ""){ // TELEFON 
                if($numerTelefonu != html_entity_decode($_POST["TELEFON_FROM_JS"])){
                    $data_from_GUS["numerTelefonu"] = $numerTelefonu;
                    $elements_data[$num] = 1;
                    $num++;
                } else {
                    $data_from_GUS["numerTelefonu"] = "SAME_DATA";
                    $elements_data[$num] = 3;
                    $num++;
                }
            } else {
                $data_from_GUS["numerTelefonu"] = "EMPTY_DATA_FROM_GUS";
                $elements_data[$num] = 2;
                $num++;
            }
        }
        if ( html_entity_decode($_POST["FAKS_FROM_JS"]) != "EMPTY_FIELD" ){
            if($numerFaksu != ""){ // FAKS 
                if($numerFaksu != html_entity_decode($_POST["FAKS_FROM_JS"])){
                    $data_from_GUS["numerFaksu"] = $numerFaksu;
                    $elements_data[$num] = 1;
                    $num++;
                } else {
                    $data_from_GUS["numerFaksu"] = "SAME_DATA";
                    $elements_data[$num] = 3;
                    $num++;
                }
            } else {
                $data_from_GUS["numerFaksu"] = "EMPTY_DATA_FROM_GUS";
                $elements_data[$num] = 2;
                $num++;
            }
        }
        if ( html_entity_decode($_POST["FORMA_DZIALALNOSC_FROM_JS"]) != "EMPTY_FIELD" ){ 
            if($formaDzialalnosc != ""){ // FORMA DZIAŁALNOŚCI
                if($formaDzialalnosc != html_entity_decode($_POST["FORMA_DZIALALNOSC_FROM_JS"])){
                    $data_from_GUS["formaDzialalnosc"] = $formaDzialalnosc;
                    $elements_data[$num] = 1;
                    $num++;
                } else {
                    $data_from_GUS["formaDzialalnosc"] = "SAME_DATA";
                    $elements_data[$num] = 3;
                    $num++;
                }
            } else {
                $data_from_GUS["formaDzialalnosc"] = "EMPTY_DATA_FROM_GUS";
                $elements_data[$num] = 2;
                $num++;
            }
        }
        if ( html_entity_decode($_POST["ADRES_FROM_JS"]) != "EMPTY_FIELD" ){
            if($adres != ""){ // ADRES
                if($adres != html_entity_decode($_POST["ADRES_FROM_JS"])){
                    $data_from_GUS["adres"] = $adres;
                    $elements_data[$num] = 1;
                    $num++;
                } else {
                    $data_from_GUS["adres"] = "SAME_DATA";
                    $elements_data[$num] = 3;
                    $num++;
                }
            } else {
                $data_from_GUS["adres"] = "EMPTY_DATA_FROM_GUS";
                $elements_data[$num] = 2;
                $num++;
            }
        }
        if ( html_entity_decode($_POST["MIASTO_FROM_JS"]) != "EMPTY_FIELD" ){
            if($miasto != ""){ // MIASTO 
                if($miasto != html_entity_decode($_POST["MIASTO_FROM_JS"])){
                    $data_from_GUS["miasto"] = $miasto;
                    $elements_data[$num] = 1;
                    $num++;
                } else {
                    $data_from_GUS["miasto"] = "SAME_DATA";
                    $elements_data[$num] = 3;
                    $num++;
                }
            } else {
                $data_from_GUS["miasto"] = "EMPTY_DATA_FROM_GUS";
                $elements_data[$num] = 2;
                $num++;
            }
        }
        if ( html_entity_decode($_POST["WOJEWODZTWO_FROM_JS"]) != "EMPTY_FIELD" ){
            if($wojewodztwo != ""){ // WOJEWÓDZTWO 
                if($wojewodztwo != html_entity_decode($_POST["WOJEWODZTWO_FROM_JS"])){
                    $data_from_GUS["wojewodztwo"] = $wojewodztwo;
                    $elements_data[$num] = 1;
                    $num++;
                } else {
                    $data_from_GUS["wojewodztwo"] = "SAME_DATA";
                    $elements_data[$num] = 3;
                    $num++;
                }
            } else {
                $data_from_GUS["wojewodztwo"] = "EMPTY_DATA_FROM_GUS";
                $elements_data[$num] = 2;
                $num++;
            }
        }
        if ( html_entity_decode($_POST["KOD_POCZTOWY_FROM_JS"]) != "EMPTY_FIELD" ){
            if($kodPocztowy != ""){ // KOD POCZTOWY 
                if($kodPocztowy != html_entity_decode($_POST["KOD_POCZTOWY_FROM_JS"])){
                    $data_from_GUS["kodPocztowy"] = $kodPocztowy;
                    $elements_data[$num] = 1;
                    $num++;
                } else {
                    $data_from_GUS["kodPocztowy"] = "SAME_DATA";
                    $elements_data[$num] = 3;
                    $num++;
                }
            } else {
                $data_from_GUS["kodPocztowy"] = "EMPTY_DATA_FROM_GUS";
                $elements_data[$num] = 2;
                $num++;
            }
        }
        if ( html_entity_decode($_POST["KRAJ_FROM_JS"]) != "EMPTY_FIELD" ){
            if($kraj != ""){ // KRAJ 
                if($kraj != html_entity_decode($_POST["KRAJ_FROM_JS"])){
                    $data_from_GUS["kraj"] = $kraj;
                    $elements_data[$num] = 1;
                    $num++;
                } else {
                    $data_from_GUS["kraj"] = "SAME_DATA";
                    $elements_data[$num] = 3;
                    $num++;
                }
            } else {
                $data_from_GUS["kraj"] = "EMPTY_DATA_FROM_GUS";
                $elements_data[$num] = 2;
                $num++;
            }
        }
        if ( html_entity_decode($_POST["NR_NIERUCHOMOSCI_FROM_JS"]) != "EMPTY_FIELD" ){
            if($numerNieruchomosci != ""){ // NR NIERUCHOMOŚCI 
                if($numerNieruchomosci != html_entity_decode($_POST["NR_NIERUCHOMOSCI_FROM_JS"])){
                    $data_from_GUS["numerNieruchomosci"] = $numerNieruchomosci;
                    $elements_data[$num] = 1;
                    $num++;
                } else {
                    $data_from_GUS["numerNieruchomosci"] = "SAME_DATA";
                    $elements_data[$num] = 3;
                    $num++;
                }
            } else {
                $data_from_GUS["numerNieruchomosci"] = "EMPTY_DATA_FROM_GUS";
                $elements_data[$num] = 2;
                $num++;
            }
        }
        if ( html_entity_decode($_POST["NR_MIESZKANIA_FROM_JS"]) != "EMPTY_FIELD" ){
            if($numerMieszkania != ""){ // NR MIESZKANIA 
                if($numerMieszkania != html_entity_decode($_POST["NR_MIESZKANIA_FROM_JS"])){
                    $data_from_GUS["numerMieszkania"] = $numerMieszkania;
                    $elements_data[$num] = 1;
                    $num++;
                } else {
                    $data_from_GUS["numerMieszkania"] = "SAME_DATA";
                    $elements_data[$num] = 3;
                    $num++;
                }
            } else {
                $data_from_GUS["numerMieszkania"] = "EMPTY_DATA_FROM_GUS";
                $elements_data[$num] = 2;
                $num++;
            }
        }
        if ( html_entity_decode($_POST["WEBSITE_FROM_JS"]) != "EMPTY_FIELD" ){
            if($adresStronyinternetowej != ""){ // WEBSITE 
                if($adresStronyinternetowej != html_entity_decode($_POST["WEBSITE_FROM_JS"])){
                    $data_from_GUS["website"] = $adresStronyinternetowej;
                    $elements_data[$num] = 1;
                    $num++;
                } else {
                    $data_from_GUS["website"] = "SAME_DATA";
                    $elements_data[$num] = 3;
                    $num++;
                }
            } else {
                $data_from_GUS["website"] = "EMPTY_DATA_FROM_GUS";
                $elements_data[$num] = 2;
                $num++;
            }  
        }
        if ( html_entity_decode($_POST["DATA_POWSTANIA_FROM_JS"]) != "EMPTY_FIELD" ){
            if($dataPowstania != ""){ // DATA POWSTANIA 
                if($dataPowstania != html_entity_decode($_POST["DATA_POWSTANIA_FROM_JS"])){
                    $data_from_GUS["dataPowstania"] = $dataPowstania;
                    $elements_data[$num] = 1;
                    $num++;
                } else {
                    $data_from_GUS["dataPowstania"] = "SAME_DATA";
                    $elements_data[$num] = 3;
                    $num++;
                }
            } else {
                $data_from_GUS["dataPowstania"] = "EMPTY_DATA_FROM_GUS";
                $elements_data[$num] = 2;
                $num++;
            }
        }
        if ( html_entity_decode($_POST["DATA_ROZPOCZECIA_DZIALALNOSCI_FROM_JS"]) != "EMPTY_FIELD" ){
            if($dataRozpoczeciaDzialalnosci != ""){ // DATA ROZPOCZECIA DZIALALNOSCI
                if($dataRozpoczeciaDzialalnosci != html_entity_decode($_POST["DATA_ROZPOCZECIA_DZIALALNOSCI_FROM_JS"])){
                    $data_from_GUS["dataRozpoczeciaDzialalnosci"] = $dataRozpoczeciaDzialalnosci;
                    $elements_data[$num] = 1;
                    $num++;
                } else {
                    $data_from_GUS["dataRozpoczeciaDzialalnosci"] = "SAME_DATA";
                    $elements_data[$num] = 3;
                    $num++;
                }
            } else {
                $data_from_GUS["dataRozpoczeciaDzialalnosci"] = "EMPTY_DATA_FROM_GUS";
                $elements_data[$num] = 2;
                $num++;
            }
        }
        if ( html_entity_decode($_POST["DATA_ZAKONCZENIA_DZIALALNOSCI_FROM_JS"]) != "EMPTY_FIELD" ){
            if($dataZakonczeniaDzialalnosci != ""){ // DATA ZAKONCZENIA DZIALALNOSCI 
                if($dataZakonczeniaDzialalnosci != html_entity_decode($_POST["DATA_ZAKONCZENIA_DZIALALNOSCI_FROM_JS"])){
                    $data_from_GUS["dataZakonczeniaDzialalnosci"] = $dataZakonczeniaDzialalnosci;
                    $elements_data[$num] = 1;
                    $num++;
                } else {
                    $data_from_GUS["dataZakonczeniaDzialalnosci"] = "SAME_DATA";
                    $elements_data[$num] = 3;
                    $num++;
                }
            } else {
                $data_from_GUS["dataZakonczeniaDzialalnosci"] = "EMPTY_DATA_FROM_GUS";
                $elements_data[$num] = 2;
                $num++;
            }
        }
        if ( html_entity_decode($_POST["DATA_WZNOWIENIA_DZIALALNOSCI_FROM_JS"]) != "EMPTY_FIELD" ){
            if($dataWznowieniaDzialalnosci != ""){ // DATA WZNOWIENIA DZIALALNOSCI
            if($dataWznowieniaDzialalnosci != html_entity_decode($_POST["DATA_WZNOWIENIA_DZIALALNOSCI_FROM_JS"])){
                    $data_from_GUS["dataWznowieniaDzialalnosci"] = $dataWznowieniaDzialalnosci;
                    $elements_data[$num] = 1;
                    $num++;
                } else {
                    $data_from_GUS["dataWznowieniaDzialalnosci"] = "SAME_DATA";
                    $elements_data[$num] = 3;
                    $num++;
                }
            } else {
                $data_from_GUS["dataWznowieniaDzialalnosci"] = "EMPTY_DATA_FROM_GUS";
                $elements_data[$num] = 2;
                $num++;
            }
        }
        if ( html_entity_decode($_POST["DATA_ZAWIESZENIA_DZIALALNOSCI_FROM_JS"]) != "EMPTY_FIELD" ){
            if($dataZawieszeniaDzialalnosci != ""){ // DATA ZAWIESZENIA DZIALALNOSCI
               if($dataZawieszeniaDzialalnosci != html_entity_decode($_POST["DATA_ZAWIESZENIA_DZIALALNOSCI_FROM_JS"])){
                    $data_from_GUS["dataZawieszeniaDzialalnosci"] = $dataZawieszeniaDzialalnosci;
                    $elements_data[$num] = 1;
                    $num++;
                } else {
                    $data_from_GUS["dataZawieszeniaDzialalnosci"] = "SAME_DATA";
                    $elements_data[$num] = 3;
                    $num++;
                }
            } else {
                $data_from_GUS["dataZawieszeniaDzialalnosci"] = "EMPTY_DATA_FROM_GUS";
                $elements_data[$num] = 2;
                $num++;
            }
        }
        if ( html_entity_decode($_POST["DATA_ORZECZENIA_O_UPADLOSCI_FROM_JS"]) != "EMPTY_FIELD" ){
            if($dataOrzeczeniaOUpadlosci != ""){ // DATA ORZECZENIA O UPADLOSCI
                if($dataOrzeczeniaOUpadlosci != html_entity_decode($_POST["DATA_ORZECZENIA_O_UPADLOSCI_FROM_JS"])){
                    $data_from_GUS["dataOrzeczeniaOUpadlosci"] = $dataOrzeczeniaOUpadlosci;
                    $elements_data[$num] = 1;
                    $num++;
                } else {
                    $data_from_GUS["dataOrzeczeniaOUpadlosci"] = "SAME_DATA";
                    $elements_data[$num] = 3;
                    $num++;
                }
            } else {
                $data_from_GUS["dataOrzeczeniaOUpadlosci"] = "EMPTY_DATA_FROM_GUS";
                $elements_data[$num] = 2;
                $num++;
            }
        }
        if ( html_entity_decode($_POST["DATA_ZAKONCZENIA_POSTEPOWANIA_UPADLOSCIOWEGO_FROM_JS"]) != "EMPTY_FIELD" ){
            if($dataZakonczeniaPostepowaniaUpadlosciowego != ""){ // DATA ZAKONCZENIA POSTEPOWANIA UPADLOSCIOWEGO
                if($dataZakonczeniaPostepowaniaUpadlosciowego != html_entity_decode($_POST["DATA_ZAKONCZENIA_POSTEPOWANIA_UPADLOSCIOWEGO_FROM_JS"])){
                    $data_from_GUS["dataZakonczeniaPostepowaniaUpadlosciowego"] = $dataZakonczeniaPostepowaniaUpadlosciowego;
                    $elements_data[$num] = 1;
                } else {
                    $data_from_GUS["dataZakonczeniaPostepowaniaUpadlosciowego"] = "SAME_DATA";
                    $elements_data[$num] = 3;
                }
            } else {
                $data_from_GUS["dataZakonczeniaPostepowaniaUpadlosciowego"] = "EMPTY_DATA_FROM_GUS";
                $elements_data[$num] = 2;
            }
        }
        $x = 0;
        foreach ($elements_data as $element) {
            if($element != 1) $x++;
        }
        if($x == $elements){
            $message_box["check_data"] = FALSE;
        } else {
            $message_box["check_data"] = TRUE;
        }
        $message_box["dane_od_gus"] = $data_from_GUS;
        $message_box["x"] = $x;
        $message_box["elements"] = $elements;  
        $message_box["status"] = 0;
        echo json_encode($message_box);
    } catch (InvalidUserKeyException $e) {
        $message_box["status"] = 1;
        $message_box["message"] = "Błąd połaczenia z bazą REGON, błędny klucz";
        echo json_encode($message_box);
    } catch (NotFoundException $e) {
        $message_box["status"] = 1;
        $message_box["message"] = "Nie znaleziono podmiotu Bazie Internetowej Regon, zazwyczaj oznacza to wprowadzenie błędnego NIPu.";
        echo json_encode($message_box);
    } catch (InvalidServerResponseException $e) {
        $message_box["status"] = 1;
        $message_box["message"] = "Błąd połączenia z bazą REGON, serwer nie odpowiada lub nie działa. Spróbuj później.";
        echo json_encode($message_box);
    } catch (InvalidReportTypeException $e) {
        $message_box["status"] = 1;
        $message_box["message"] = "Nie poprawny typ raportu!";
        echo json_encode($message_box);
    }
} else { // REKORD NIP ROZNI OD POLA DANYCH NIP 
    if($row){ // JESLI WPROWADZONY NIP JEST W BAZIE DANYCH TO OD RAZU WYSYLA ODPOWIEDZ DO JS ZE ISTNIEJE TAKI KONTRAHENT
        $message_box["status"] = 1;
        $message_box["message"] = "Istnieje już kontrahent w bazie z identycznym numerem NIP.";
        echo json_encode($message_box);
    } else { // W PRZECIWNYM RAZIE POBIERA POTRZEBNE DANE I ZWRACA DO JS
        //Logowanie
        $gus = new GusApi("f8a8222ca4244368b3df");
        $gus->login();

        try {
            $gusReport = $gus->getByNip(html_entity_decode($_POST["NIP_FROM_JS"]))[0];  // Wyszukiwanie kontkraetnego nipa
            $reportType = ReportTypes::REPORT_PUBLIC_LAW;                               // Przypisanie typ podmiotu
            $fullReport = $gus->getFullReport($gusReport, $reportType);                 // Pobranie dane konkretnego nipa z podmiotem

            //POBRANIE RAPORTU
            if( $fullReport[0][praw_podstawowaFormaPrawna_Symbol] == NULL && $fullReport[0][praw_szczegolnaFormaPrawna_Symbol] == NULL ){
                $reportType = ReportTypes::REPORT_ACTIVITY_PHYSIC_CEIDG;
                $fullReport = $gus->getFullReport($gusReport, $reportType);
                $nazwa = $gusReport->getName();                                                                                 //  NAZWA
                $numerTelefonu = $fullReport[0][fiz_numerTelefonu];                                                            //  NUMER TELEFONU
                $numerFaksu = $fullReport[0][fiz_numerFaksu];                                                                  //  NUMER FAKSU
                $ulica = $gusReport->getStreet();                                                                               //  ULICA
                $numerNieruchomosci = $gusReport->getPropertyNumber();                                                          //  NUMER NIERUCHOMOSCI
                $adres = $ulica." ".$numerNieruchomosci;                                                                        //  ADRES
                $miasto = $gusReport->getCity();                                                                                //  MIASTO                                                                                                         
                $wojewodztwo = $gusReport->getProvince();                                                                       //  WOJEWODZTWO
                $kraj = $fullReport[0][fiz_adSiedzKraj_Nazwa];                                                                 //  KRAJ
                $kodPocztowy = $gusReport->getZipCode();                                                                        //  KOD POCZTOWY
                $numerMieszkania = $gusReport->getApartmentNumber();                                                            //  NUMER MIESZKANIA
                $adresStronyinternetowej = $fullReport[0][fiz_adresStronyinternetowej];                                        //  ADRES STRONY INTERNETOWEJ
                $dataPowstania = $fullReport[0][fiz_dataPowstania];                                                            //  DATA POWSTANIA
                $dataRozpoczeciaDzialalnosci = $fullReport[0][fiz_dataRozpoczeciaDzialalnosci];                                //  DATA ROZPOCZĘCIA DZIAŁANOŚCI
                $dataZakonczeniaDzialalnosci = $fullReport[0][fiz_dataZakonczeniaDzialalnosci];                                //  DATA ZAKONCZENIA DZIAŁAŁNOSCI
                $dataZawieszeniaDzialalnosci = $fullReport[0][fiz_dataZawieszeniaDzialalnosci];                                //  DATA ZAWIESZENIA DZIAŁAŁNOSCI
                $dataWznowieniaDzialalnosci = $fullReport[0][fiz_dataWznowieniaDzialalnosci];                                  //  DATA WZNOWIENIA DZIAŁAŁNOSCI
                $dataOrzeczeniaOUpadlosci = $fullReport[0][fiz_dataOrzeczeniaOUpadlosci];                                      //  DATA ORZECZENIA O UPADŁOSCI
                $dataZakonczeniaPostepowaniaUpadlosciowego = $fullReport[0][fiz_dataZakonczeniaPostepowaniaUpadlosciowego];    //  DATA ZAKONCZENIA POSTĘPOWANIA UPADŁOSCIOWEGO
                $dataZaistnieniaZmiany = $fullReport[0][fiz_dataZaistnieniaZmiany];                                            //  DATA ZAISTNIENIA ZMIANY
                $nip = $fullReport[0][fiz_nip];
    
                $reportType = ReportTypes::REPORT_ACTIVITY_PHYSIC_PERSON;
                $fullReport = $gus->getFullReport($gusReport, $reportType);
                $podstawowaFormaPrawna_Symbol = $fullReport[0][fiz_podstawowaFormaPrawna_Symbol];
                $szczegolnaFormaPrawna_Symbol = $fullReport[0][fiz_szczegolnaFormaPrawna_Symbol]; 
    
            } else {
                $nazwa = $gusReport->getName();                                                                                 //  NAZWA
                $numerTelefonu = $fullReport[0][praw_numerTelefonu];                                                            //  NUMER TELEFONU
                $numerFaksu = $fullReport[0][praw_numerFaksu];                                                                  //  NUMER FAKSU
                $podstawowaFormaPrawna_Symbol = $fullReport[0][praw_podstawowaFormaPrawna_Symbol];                              //  PODSTATOWA FORMA PRAWNA SYMBOL
                $szczegolnaFormaPrawna_Symbol = $fullReport[0][praw_szczegolnaFormaPrawna_Symbol];                              //  SZCZEGOLNA FORMA PRAWNA SYMBOL
                $ulica = $gusReport->getStreet();                                                                               //  ULICA
                $numerNieruchomosci = $gusReport->getPropertyNumber();                                                          //  NUMER NIERUCHOMOSCI
                $adres = $ulica." ".$numerNieruchomosci;                                                                        //  ADRES
                $miasto = $gusReport->getCity();                                                                                //  MIASTO                                                                                                         
                $wojewodztwo = $gusReport->getProvince();                                                                       //  WOJEWODZTWO
                $kraj = $fullReport[0][praw_adSiedzKraj_Nazwa];                                                                 //  KRAJ
                $kodPocztowy = $gusReport->getZipCode();                                                                        //  KOD POCZTOWY
                $numerMieszkania = $gusReport->getApartmentNumber();                                                            //  NUMER MIESZKANIA
                $adresStronyinternetowej = $fullReport[0][praw_adresStronyinternetowej];                                        //  ADRES STRONY INTERNETOWEJ
                $dataPowstania = $fullReport[0][praw_dataPowstania];                                                            //  DATA POWSTANIA
                $dataRozpoczeciaDzialalnosci = $fullReport[0][praw_dataRozpoczeciaDzialalnosci];                                //  DATA ROZPOCZĘCIA DZIAŁANOŚCI
                $dataZakonczeniaDzialalnosci = $fullReport[0][praw_dataZakonczeniaDzialalnosci];                                //  DATA ZAKONCZENIA DZIAŁAŁNOSCI
                $dataZawieszeniaDzialalnosci = $fullReport[0][praw_dataZawieszeniaDzialalnosci];                                //  DATA ZAWIESZENIA DZIAŁAŁNOSCI
                $dataWznowieniaDzialalnosci = $fullReport[0][praw_dataWznowieniaDzialalnosci];                                  //  DATA WZNOWIENIA DZIAŁAŁNOSCI
                $dataOrzeczeniaOUpadlosci = $fullReport[0][praw_dataOrzeczeniaOUpadlosci];                                      //  DATA ORZECZENIA O UPADŁOSCI
                $dataZakonczeniaPostepowaniaUpadlosciowego = $fullReport[0][praw_dataZakonczeniaPostepowaniaUpadlosciowego];    //  DATA ZAKONCZENIA POSTĘPOWANIA UPADŁOSCIOWEGO
                $dataZaistnieniaZmiany = $fullReport[0][praw_dataZaistnieniaZmiany];                                            //  DATA ZAISTNIENIA ZMIANY
                $nip = $fullReport[0][praw_nip];
            }
            $formaDzialalnosc = $arr_account_type[$podstawowaFormaPrawna_Symbol][$szczegolnaFormaPrawna_Symbol];            //  FORMA DZIAŁALNOŚĆI
            //--------------------------------------------------------------------------------------------------------------||
            $gus->logout(); //WYLOGOWANIE


            $data_from_GUS = array();
            // 1 - istnieje dane
            // 2 - puste dane
            if ( html_entity_decode($_POST["NAZWA_FROM_JS"]) != "EMPTY_FIELD" ) {
                if($nazwa != ""){ // NAZWA
                    $data_from_GUS["nazwa"] = $nazwa;
                } else {
                    $data_from_GUS["nazwa"] = "EMPTY_DATA_FROM_GUS";
                }
            }
            if ( html_entity_decode($_POST["TELEFON_FROM_JS"]) != "EMPTY_FIELD" ) {
                if($numerTelefonu != ""){ // TELEFON
                    $data_from_GUS["numerTelefonu"] = $numerTelefonu;
                } else {
                    $data_from_GUS["numerTelefonu"] = "EMPTY_DATA_FROM_GUS";
                }
            }
            if ( html_entity_decode($_POST["FAKS_FROM_JS"]) != "EMPTY_FIELD" ) {
                if($numerFaksu != ""){ // FAKS
                    $data_from_GUS["numerFaksu"] = $numerFaksu;
                } else {
                    $data_from_GUS["numerFaksu"] = "EMPTY_DATA_FROM_GUS";
                }
            }
            if ( html_entity_decode($_POST["FORMA_DZIALALNOSC_FROM_JS"]) != "EMPTY_FIELD" ) {
                if($formaDzialalnosc != ""){ // FORMA DZIAŁALNOŚCI
                    $data_from_GUS["formaDzialalnosc"] = $formaDzialalnosc;
                } else {
                    $data_from_GUS["formaDzialalnosc"] = "EMPTY_DATA_FROM_GUS";
                }
            }
            if ( html_entity_decode($_POST["ADRES_FROM_JS"]) != "EMPTY_FIELD" ) {
                if($adres != ""){ // ADRES
                    $data_from_GUS["adres"] = $adres;
                } else {
                    $data_from_GUS["adres"] = "EMPTY_DATA_FROM_GUS";
                }
            }
            if ( html_entity_decode($_POST["MIASTO_FROM_JS"]) != "EMPTY_FIELD" ) {
                if($miasto != ""){ // MIASTO
                    $data_from_GUS["miasto"] = $miasto;
                } else {
                    $data_from_GUS["miasto"] = "EMPTY_DATA_FROM_GUS";
                }
            }
            if ( html_entity_decode($_POST["WOJEWODZTWO_FROM_JS"]) != "EMPTY_FIELD" ) {
                if($wojewodztwo != ""){ // WOJEWÓDZTWO
                    $data_from_GUS["wojewodztwo"] = $wojewodztwo;
                } else {
                    $data_from_GUS["wojewodztwo"] = "EMPTY_DATA_FROM_GUS";
                }
            }
            if ( html_entity_decode($_POST["KOD_POCZTOWY_FROM_JS"]) != "EMPTY_FIELD" ) {
                if($kodPocztowy != ""){ // KOD POCZTOWY
                    $data_from_GUS["kodPocztowy"] = $kodPocztowy;
                } else {
                    $data_from_GUS["kodPocztowy"] = "EMPTY_DATA_FROM_GUS";
                }
            }
            if ( html_entity_decode($_POST["KRAJ_FROM_JS"]) != "EMPTY_FIELD" ) {
                if($kraj != ""){ // KRAJ
                    $data_from_GUS["kraj"] = $kraj;
                } else {
                    $data_from_GUS["kraj"] = "EMPTY_DATA_FROM_GUS";
                }
            }
            if ( html_entity_decode($_POST["NR_NIERUCHOMOSCI_FROM_JS"]) != "EMPTY_FIELD" ) {
                if($numerNieruchomosci != ""){ // NR NIERUCHOMOŚCI
                    $data_from_GUS["numerNieruchomosci"] = $numerNieruchomosci;
                } else {
                    $data_from_GUS["numerNieruchomosci"] = "EMPTY_DATA_FROM_GUS";
                }
            }
            if ( html_entity_decode($_POST["NR_MIESZKANIA_FROM_JS"]) != "EMPTY_FIELD" ) {
                if($numerMieszkania != ""){ // NR MIESZKANIA
                    $data_from_GUS["numerMieszkania"] = $numerMieszkania;
                } else {
                    $data_from_GUS["numerMieszkania"] = "EMPTY_DATA_FROM_GUS";
                }
            }
            if ( html_entity_decode($_POST["WEBSITE_FROM_JS"]) != "EMPTY_FIELD" ) {
                if($adresStronyinternetowej != ""){ // WEBSITE
                    $data_from_GUS["website"] = $adresStronyinternetowej;
                } else {
                    $data_from_GUS["website"] = "EMPTY_DATA_FROM_GUS";
                }
            }
            if ( html_entity_decode($_POST["DATA_POWSTANIA_FROM_JS"]) != "EMPTY_FIELD" ) {
                if($dataPowstania != ""){ // DATA POWSTANIA
                    $data_from_GUS["dataPowstania"] = $dataPowstania;
                } else {
                    $data_from_GUS["dataPowstania"] = "EMPTY_DATA_FROM_GUS";
                }
            }
            if ( html_entity_decode($_POST["DATA_ROZPOCZECIA_DZIALALNOSCI_FROM_JS"]) != "EMPTY_FIELD" ) {
                if($dataRozpoczeciaDzialalnosci != ""){ // DATA ROZPOCZĘCIA DZIAŁALNOŚCI
                    $data_from_GUS["dataRozpoczeciaDzialalnosci"] = $dataRozpoczeciaDzialalnosci;
                } else {
                    $data_from_GUS["dataRozpoczeciaDzialalnosci"] = "EMPTY_DATA_FROM_GUS";
                }
            }
            if ( html_entity_decode($_POST["DATA_ZAKONCZENIA_DZIALALNOSCI_FROM_JS"]) != "EMPTY_FIELD" ) {
                if($dataZakonczeniaDzialalnosci != ""){ // DATA ZAKOŃCZENIA DZIAŁALNOŚCI
                    $data_from_GUS["dataZakonczeniaDzialalnosci"] = $dataZakonczeniaDzialalnosci;
                } else {
                    $data_from_GUS["dataZakonczeniaDzialalnosci"] = "EMPTY_DATA_FROM_GUS";
                }
            }
            if ( html_entity_decode($_POST["DATA_WZNOWIENIA_DZIALALNOSCI_FROM_JS"]) != "EMPTY_FIELD" ) {
                if($dataWznowieniaDzialalnosci != ""){ // DATA WZNOWIENIA DZIAŁALNOŚCI
                    $data_from_GUS["dataWznowieniaDzialalnosci"] = $dataWznowieniaDzialalnosci;
                } else {
                    $data_from_GUS["dataWznowieniaDzialalnosci"] = "EMPTY_DATA_FROM_GUS";
                }
            }
            if ( html_entity_decode($_POST["DATA_ZAWIESZENIA_DZIALALNOSCI_FROM_JS"]) != "EMPTY_FIELD" ) {
                if($dataZawieszeniaDzialalnosci != ""){ // DATA ZAWIESZENIA DZIAŁALNOŚCI
                    $data_from_GUS["dataZawieszeniaDzialalnosci"] = $dataZawieszeniaDzialalnosci;
                } else {
                    $data_from_GUS["dataZawieszeniaDzialalnosci"] = "EMPTY_DATA_FROM_GUS";
                }
            }
            if ( html_entity_decode($_POST["DATA_ORZECZENIA_O_UPADLOSCI_FROM_JS"]) != "EMPTY_FIELD" ) {
                if($dataOrzeczeniaOUpadlosci != ""){ // DATA ORZECZENIA O UPADŁOŚCI
                    $data_from_GUS["dataOrzeczeniaOUpadlosci"] = $dataOrzeczeniaOUpadlosci;
                } else {
                    $data_from_GUS["dataOrzeczeniaOUpadlosci"] = "EMPTY_DATA_FROM_GUS";
                }
            }
            if ( html_entity_decode($_POST["DATA_ZAKONCZENIA_POSTEPOWANIA_UPADLOSCIOWEGO_FROM_JS"]) != "EMPTY_FIELD" ) {
                if($dataZakonczeniaPostepowaniaUpadlosciowego != ""){ // DATA ZAKOŃCZENIA POSTĘPOWANIA UPADŁOSCIOWEGO 
                    $data_from_GUS["dataZakonczeniaPostepowaniaUpadlosciowego"] = $dataZakonczeniaPostepowaniaUpadlosciowego;
                } else {
                    $data_from_GUS["dataZakonczeniaPostepowaniaUpadlosciowego"] = "EMPTY_DATA_FROM_GUS";
                }
            }
            $message_box["check_data"] = TRUE;
            $message_box["dane_od_gus"] = $data_from_GUS;
            $message_box["status"] = 0;
            echo json_encode($message_box);
        } catch (InvalidUserKeyException $e) {
            $message_box["status"] = 1;
            $message_box["message"] = "Błąd połaczenia z bazą REGON, błędny klucz";
            echo json_encode($message_box);
        } catch (NotFoundException $e) {
            $message_box["status"] = 1;
            $message_box["message"] = "Nie znaleziono podmiotu Bazie Internetowej Regon, zazwyczaj oznacza to wprowadzenie błędnego NIPu.";
            echo json_encode($message_box);
        } catch (InvalidServerResponseException $e) {
            $message_box["status"] = 1;
            $message_box["message"] = "Błąd połączenia z bazą REGON, serwer nie odpowiada lub nie działa. Spróbuj później.";
            echo json_encode($message_box);
        } catch (InvalidReportTypeException $e) {
            $message_box["status"] = 1;
            $message_box["message"] = "Nie poprawny typ raportu!";
            echo json_encode($message_box);
        }
    }
}
?>


