/**
 * Jeśli skrypt nie będzie działać prawidłowo to trzeba zmienić identyfikatory tutaj lub w suitecrm
 * 
 * Identyfikatory od HTML:
 *  name - Nazwa
 *  nip_c - NIP
 *  typ_firmy_c - Typ firmy
 *  account_type - Forma działalności
 *  
 * 
 * Przyczyny błędy:
 *  (1) - Nie odnaleziono pola danych Nazwę, NIP, Typ firmy , Forma działalności - Trzeba dodać te pola danych do suitecrm.
 * 
 * Jeśli dodałeś inne pole danych i chcesz żeby prawidłowo pobrał dane to musisz dodać kilka instrukcji -> NASCNIJ CTRL+F i wpisz ADD_MORE_DATA
 */

/** disabled_button_by_time - zablokuje,wyłącza przycisk przez n sekundy
 * @param {, id : int, sec : int }
 */
function disabled_button_by_time(id,sec){
    document.getElementById(id).disabled = true;
    setTimeout(function(){ document.getElementById(id).disabled = false; }, sec);
}
/** check_window_before_validity - Przed walidacją danych, sprawdza jaki to rodzaj widoku. (Edycja czy utworzenie kontrahentów)*/
function check_window_before_validity(){
    disabled_button_by_time("SAVE",1500); // Zablokuje przycisk przez 1,5 sekundy
    var element_module_title = document.querySelector(".module-title-text").innerHTML; // NIE USUWAC! (Ta zmienna jest bardzo potrzebna do wykrycia okna (ono wykryje okno edycję kontrahenta równiez okno utworzenie kontrahenta.)
    // Sprawdzenie okna Suitecrm
    if(element_module_title.search("Utwórz") != -1 || element_module_title.search("Edytuj") != -1) {    // Jesli istnieje element z stringiem "Utwórz" lub "edytuj" rozpocznie walidacja poprawnosci danych
        // Okno utworzenia kontrahenta
        if(element_module_title.search("Utwórz") != -1){
            validity_data("","Utworzenie");
        // Okno edycji kontrahnta
        } else {
            //Pobiera id rekordu kontrahenta i wysyła do funkcji validity_data
            var id_record = element_module_title.substring(element_module_title.search("record")+7,105);
            validity_data(id_record,"Edycja");
        }
    } else {    // W przeciwnym razie wyświetla komunikat
        alert("Przepraszamy! Nastąpił błąd w programie. Prosze zgłosić do administratora.");
        console.log("Skrypt będzie nie działać, jeśli nie jestes na widoku edycji lub tworzenia nowego kontrahenta w modułu Accounts"); 
    }
}
/** check_pattern_nip - sprawdza nip czy to jest prawidlowy wzór nip'a. także usuwa puste znaki i '-'
 * @param {, nip_account : int }
 */
function check_pattern_nip(nip_account){
    nip_account.value  = nip_account.value.replace(/\s/g,'');
    nip_account.value  = nip_account.value.replace(/-/g,'');
    var arr_msg = [];
    if(nip_account.value.length == 10){
        var arr_tmp = nip_account.value.split("");
        var loop = 0;
        for(var chr in arr_tmp){
            if( isNaN(parseInt(arr_tmp[chr])) ){
                arr_msg["boll"] = false;
                arr_msg["msg"] = "NIP musi zawierac tylko cyfry.";
                return arr_msg;
            } else {
                loop++;
            }
        }
        if(loop == 10){
            arr_msg["boll"] = true;
            arr_msg["after_checked_nip"] = nip_account.value;
            return arr_msg;
        }
    } else {
        arr_msg["boll"] = false;
        arr_msg["msg"] = "NIP musi zawierac 10 cyfry.";
        return arr_msg;
    }
}
/** message_field - Wyświetla oraz usuwa komunikaty pod pola danych
 * @param {, choice_num_field : int, msg_field : string }
 */
function message_field(choice_num_field, msg_field){
    var div_nip = document.createElement("div");
    var div_nazwa = document.createElement("div");
    var div_account_type = document.createElement("div");
    var div_typ_firmy = document.createElement("div");
    switch(choice_num_field){
        case 1: // TYLKO USUWA KOMUNIKAT FIELD (nazwa, typ firmy, forma działalności)
            if( document.contains(document.getElementById("message_from_nazwa")) ){
                document.getElementsByClassName("col-xs-12 col-sm-6 edit-view-row-item")[0].removeChild(document.getElementById("message_from_nazwa"));
                document.getElementById("name").style.backgroundColor = "#f7eeee";
            }
            if( document.contains(document.getElementById("message_from_typ_firmy")) ){
                document.getElementsByClassName("col-xs-12 col-sm-6 edit-view-row-item")[4].removeChild(document.getElementById("message_from_typ_firmy"));
                document.getElementById("typ_firmy_c").style.backgroundColor = "white";
            }
            if( document.contains(document.getElementById("message_from_account_type")) ){
                document.getElementsByClassName("col-xs-12 col-sm-6 edit-view-row-item")[6].removeChild(document.getElementById("message_from_account_type"));
                document.getElementById("account_type").style.backgroundColor = "white";
            }
            break;
        case 2: // WYSWIETLA RÓWNIEZ USUWA KOMUNIKAT FIELD POD POLA (nazwa, typ firmy, Forma działalności)
            if(document.getElementById("name").value == ""){ // NAZWA
                if(document.contains(document.getElementById("message_from_nazwa")) == false ){
                    div_nazwa.style.color = "red";
                    div_nazwa.innerHTML = "Błąd! Puste pole.";
                    div_nazwa.id = "message_from_nazwa";
                    document.getElementsByClassName("col-xs-12 col-sm-6 edit-view-row-item")[0].appendChild(div_nazwa);
                    document.getElementById("name").style.backgroundColor = "#ff8c8c";
                }
            } else {
                if(document.contains(document.getElementById("message_from_nazwa")) == true){
                    document.getElementsByClassName("col-xs-12 col-sm-6 edit-view-row-item")[0].removeChild(document.getElementById("message_from_nazwa"));
                    document.getElementById("name").style.backgroundColor = "#f7eeee";
                }
            }
            if(document.getElementById("typ_firmy_c").value == "") { // TYP FIRMY
                if( document.contains(document.getElementById("message_from_typ_firmy")) == false ){
                    div_typ_firmy.style.color = "red";
                    div_typ_firmy.innerHTML = "Błąd! Pole niezaznaczone.";
                    div_typ_firmy.id = "message_from_typ_firmy";
                    document.getElementsByClassName("col-xs-12 col-sm-6 edit-view-row-item")[4].appendChild(div_typ_firmy);
                    document.getElementById("typ_firmy_c").style.backgroundColor = "#ff8c8c";
                }
            } else {
                if(document.contains(document.getElementById("message_from_typ_firmy")) == true){
                    document.getElementsByClassName("col-xs-12 col-sm-6 edit-view-row-item")[4].removeChild(document.getElementById("message_from_typ_firmy"));
                    document.getElementById("typ_firmy_c").style.backgroundColor = "white";
                }
            }
            if(document.getElementById("account_type").value == ""){ // FORMA DZIAŁALNOŚĆI
                if(document.contains(document.getElementById("message_from_account_type")) == false) {
                    div_account_type.style.color = "red";
                    div_account_type.innerHTML = "Błąd! Nie wybrano pola.";
                    div_account_type.id = "message_from_account_type";
                    document.getElementsByClassName("col-xs-12 col-sm-6 edit-view-row-item")[6].appendChild(div_account_type);
                    document.getElementById("account_type").style.backgroundColor = "#ff8c8c";
                }
            } else {
                if(document.contains(document.getElementById("message_from_account_type")) == true){
                    document.getElementsByClassName("col-xs-12 col-sm-6 edit-view-row-item")[6].removeChild(document.getElementById("message_from_account_type"));
                    document.getElementById("account_type").style.backgroundColor = "white";
                }
            }
            break;
        case 3: // USUWA KOMUNIKAT FIELD POD POLA NIP
            if( document.contains(document.getElementById("message_from_nip")) ){ // USUWA KOMUNIKAT FIELD POD POLA NIP 
                document.getElementsByClassName("col-xs-12 col-sm-6 edit-view-row-item")[2].removeChild(document.getElementById("message_from_nip"));
                document.getElementById("nip_c").style.backgroundColor = "#f7eeee";
            }
            break;
        case 4: // WYŚWIETLA KOMUNIKAT FIELD POD POLA NIP
            if(document.contains(document.getElementById("message_from_nip")) == false){ // WYSWIETLA KOMUNIKAT FIELD POD POLA NIP
                div_nip.style.color = "red";
                div_nip.innerHTML = msg_field;
                div_nip.id = "message_from_nip";
                document.getElementById("nip_c").style.backgroundColor = "#ff8c8c";
                document.getElementsByClassName("col-xs-12 col-sm-6 edit-view-row-item")[2].appendChild(div_nip);
            } else { // A JEŚLI ISTNIEJE TO ZMIENIA TYLKO JEGO WŁAŚCIWOŚCI
                if(document.contains(document.getElementById("message_from_nip")) == true) document.getElementsByClassName("col-xs-12 col-sm-6 edit-view-row-item")[2].removeChild(document.getElementById("message_from_nip"));
                div_nip.style.color = "red";
                div_nip.innerHTML = msg_field;
                div_nip.id = "message_from_nip";
                document.getElementById("nip_c").style.backgroundColor = "#ff8c8c";
                document.getElementsByClassName("col-xs-12 col-sm-6 edit-view-row-item")[2].appendChild(div_nip);
            }
            break;
    }
}
/** save_account - Zapisuje kontrahent.*/
function save_account(){
    var _form = document.getElementById('EditView'); 
    _form.action.value='Save'; 
    if(check_form('EditView'))SUGAR.ajaxUI.submitForm(_form);
    return false;
}
/** validity_data - Robi walidację danych, także sprawdza poprawność danych. Jesli ok to przejdzie do pobrania danych.
 * @param {, record_id_account : int, mode_window : string }
 */
function validity_data(record_id_account,mode_window){
    if( document.getElementById("name") != null && document.getElementById("nip_c") != null && document.getElementById("typ_firmy_c") != null && document.getElementById("account_type") != null && document.getElementById("fforeign_c") != null ){
        if( document.getElementById("name").value && document.getElementById("typ_firmy_c").value && document.getElementById("account_type").value ){
            
            message_field(1);
            
            if( document.getElementById("fforeign_c").checked == false ){

                if( document.getElementById("account_type").value != "osoba_fizyczna" && document.getElementById("account_type").value != "spolka_organizacji" ){

                    if(document.getElementById("description").value.indexOf("***Osoby fizyczne lub spolka organizacji - nie sprawdzam NIPu.") != -1 || document.getElementById("description").value.indexOf("***Firma zagraniczna - nie sprawdzam NIPu.") != -1 ) document.getElementById("description").value = "";; 
                    var array_after_checked_nip = check_pattern_nip(document.getElementById("nip_c"));
                    if( array_after_checked_nip["boll"] ){
                        message_field(3);

                        if(mode_window == "Utworzenie"){
                            if( typeof validity_data.TIMES_REPEAT_IN_CREATE == 'undefined' ) { // ILOŚĆ POWTARZAJĄCYCH DZIAŁAŃ W UTWORZENIA KONTRAHENTU
                                validity_data.TIMES_REPEAT_IN_CREATE = 1;
                            }
                            if(validity_data.TIMES_REPEAT_IN_CREATE == 1) { // ZA PIERWSZYM RAZEM ZAPISUJE NIP, POBIERA DANYCH Z GUS.
                                if( typeof validity_data.NIP_IN_CREATE == 'undefined' ) validity_data.NIP_IN_CREATE = document.getElementById("nip_c").value; // NIP W OKNIE UTWORZENIA KONTEAHENTA
                                $.ajax({
                                    url: "index.php?entryPoint=download_data_from_gus_Create_Account", // URL ENtRY POINT KTÓREGO WSKAZUJE PLIKU PHP
                                    method: "post",
                                    data: {
                                        NIP_FROM_JS: document.getElementById("nip_c").value
                                    },
                                    success: function(data_JSON){
                                        if( data_JSON != "" ){
                                            var data = jQuery.parseJSON(data_JSON);
                                            if(data.status == 0){
                                                message_popup( false, 1, "", data.dane_od_gus, true);
                                                validity_data.TIMES_REPEAT_IN_CREATE++;
                                            } else {
                                                message_popup( false,2,data.message);
                                                validity_data.TIMES_REPEAT_IN_CREATE = undefined;
                                                validity_data.NIP_IN_CREATE = undefined;
                                            }
                                        } else {
                                            message_popup( false,2,"Błąd połączenia z REGON. Proszę zgłosić ten błąd do administratora." );
                                            validity_data.TIMES_REPEAT_IN_CREATE = undefined;
                                            validity_data.NIP_IN_CREATE = undefined;
                                        }
                                    },
                                    error: function(){
                                        message_popup( false, 2,"Błąd połączenia z REGON. Proszę zgłosić ten błąd do administratora." );
                                        console.error("Błąd połączenia Ajaxu - check_data_account.js lub download_data_with_check linia 110");
                                        validity_data.TIMES_REPEAT_IN_CREATE = undefined;
                                        validity_data.NIP_IN_CREATE = undefined;
                                    }
                                });
                            } else { // ZA DRUGIM RAZEM SPRAWDZA CZY TO TEN SAM NIP KTÓRY WCZESNIEJ ZOSTAŁ WPROWADZONY
                                if( validity_data.NIP_IN_CREATE == document.getElementById("nip_c").value ){
                                    validity_data.TIMES_REPEAT_IN_CREATE = undefined;
                                    validity_data.NIP_IN_CREATE = undefined;
                                    message_popup( true, 2,"Dane kontrahentu zostały dodane do bazy danych.");
                                } else {
                                    validity_data.TIMES_REPEAT_IN_CREATE = undefined;
                                    validity_data.NIP_IN_CREATE = undefined;
                                    message_popup( false, 2,"Wpisałeś niepasujący NIP z takimi danych. Proszę spróbować ponownie!");
                                }
                            }
                        } else {
                            if( typeof validity_data.TIMES_REPEAT_IN_EDIT == 'undefined' ) { // ILOŚĆ POWTARZAJĄCYCH DZIAŁAŃ W EDYCJI KONTRAHENTU
                                validity_data.TIMES_REPEAT_IN_EDIT = 1;
                            }
                            if(validity_data.TIMES_REPEAT_IN_EDIT == 1){
                                if( typeof validity_data.NIP_IN_EDIT == 'undefined' ) { // NIP PO RAZ PIERWSZ WPROWADZONY 
                                    validity_data.NIP_IN_EDIT = "";
                                }
                                if( typeof validity_data.NIP_RECORD == 'undefined' ) { // NIP REKORDU
                                    validity_data.NIP_RECORD = "";
                                }
                                $.ajax({ // ROZPOCZYNANIE POŁĄCZENIE Z ENTRY POINT (ONO WSKAZUJE PLIK KTÓRY BĘDZIE DZIAŁAĆ)
                                    url: "index.php?entryPoint=download_data_from_gus_Edit_Account",
                                    method: "post",
                                    data: {
                                        NIP_FROM_JS : document.getElementById("nip_c").value,
                                        RECORD_ID_FROM_JS : record_id_account,
                                        NAZWA_FROM_JS : document.getElementById("name").value,
                                        FORMA_DZIALALNOSC_FROM_JS : document.getElementById("account_type").value,
                                        //----------------------------------------------------------------------------------
                                        TELEFON_FROM_JS : document.getElementById("phone_office") != null ? document.getElementById("phone_office").value : "EMPTY_FIELD",
                                        FAKS_FROM_JS : document.getElementById("phone_fax") != null ? document.getElementById("phone_fax").value : "EMPTY_FIELD", 
                                        ADRES_FROM_JS : document.getElementById("billing_address_street") != null ? document.getElementById("billing_address_street").value : "EMPTY_FIELD",
                                        MIASTO_FROM_JS : document.getElementById("billing_address_city") != null ? document.getElementById("billing_address_city").value : "EMPTY_FIELD",
                                        WOJEWODZTWO_FROM_JS : document.getElementById("billing_address_state") != null ? document.getElementById("billing_address_state").value : "EMPTY_FIELD",
                                        KOD_POCZTOWY_FROM_JS : document.getElementById("billing_address_postalcode") != null ? document.getElementById("billing_address_postalcode").value : "EMPTY_FIELD",
                                        KRAJ_FROM_JS : document.getElementById("billing_address_country") != null ? document.getElementById("billing_address_country").value : "EMPTY_FIELD",
                                        NR_NIERUCHOMOSCI_FROM_JS : document.getElementById("property_number_c") != null ? document.getElementById("property_number_c").value : "EMPTY_FIELD",
                                        NR_MIESZKANIA_FROM_JS : document.getElementById("apartment_number_c") != null ? document.getElementById("apartment_number_c").value : "EMPTY_FIELD",
                                        WEBSITE_FROM_JS : document.getElementById("website") != null ? document.getElementById("website").value : "EMPTY_FIELD",
                                        DATA_POWSTANIA_FROM_JS : document.getElementById("data_created_gus_c") != null ? document.getElementById("data_created_gus_c").value : "EMPTY_FIELD",
                                        DATA_ROZPOCZECIA_DZIALALNOSCI_FROM_JS : document.getElementById("data_begin_activity_c") != null ? document.getElementById("data_begin_activity_c").value : "EMPTY_FIELD",
                                        DATA_ZAKONCZENIA_DZIALALNOSCI_FROM_JS : document.getElementById("data_end_activity_c") != null ? document.getElementById("data_end_activity_c").value : "EMPTY_FIELD",
                                        DATA_WZNOWIENIA_DZIALALNOSCI_FROM_JS : document.getElementById("data_renewal_activity_c") != null ? document.getElementById("data_renewal_activity_c").value : "EMPTY_FIELD",
                                        DATA_ZAWIESZENIA_DZIALALNOSCI_FROM_JS : document.getElementById("data_suspension_activity_c") != null ? document.getElementById("data_suspension_activity_c").value : "EMPTY_FIELD",
                                        DATA_ORZECZENIA_O_UPADLOSCI_FROM_JS : document.getElementById("date_bankruptcy_c") != null ? document.getElementById("date_bankruptcy_c").value : "EMPTY_FIELD",
                                        DATA_ZAKONCZENIA_POSTEPOWANIA_UPADLOSCIOWEGO_FROM_JS : document.getElementById("data_ending_of_bankruptcy_c") != null ? document.getElementById("data_ending_of_bankruptcy_c").value : "EMPTY_FIELD",
                                    },
                                    success: function(data_JSON){
                                        if(data_JSON != ""){
                                            var data = jQuery.parseJSON(data_JSON);
                                            if(data.status == 0){
                                                validity_data.NIP_RECORD = data.RECORD_NIP_FROM_PHP;
                                                validity_data.NIP_IN_EDIT = document.getElementById("nip_c").value;
                                                if(document.getElementById("nip_c").value == validity_data.NIP_RECORD){
                                                    if(data.check_data){
                                                        message_popup( false, 1, "", data.dane_od_gus, false );
                                                        validity_data.TIMES_REPEAT_IN_EDIT++;
                                                    } else {
                                                        validity_data.TIMES_REPEAT_IN_EDIT = undefined;
                                                        validity_data.NIP_IN_EDIT = undefined;
                                                        validity_data.NIP_RECORD = undefined;
                                                        save_account();
                                                    }
                                                } else {
                                                    clear_data(4);
                                                    message_popup( false, 1, "", data.dane_od_gus, true );
                                                    validity_data.TIMES_REPEAT_IN_EDIT++;
                                                }
                                            } else{
                                                message_popup( false,2,data.message);
                                                validity_data.TIMES_REPEAT_IN_EDIT = undefined;
                                                validity_data.NIP_IN_EDIT = undefined;
                                            }
                                        } else {
                                            message_popup( false,2,"Błąd połączenia z REGON. Proszę zgłosić ten błąd do administratora." );
                                            validity_data.TIMES_REPEAT_IN_EDIT = undefined;
                                            validity_data.NIP_IN_EDIT = undefined;
                                            validity_data.NIP_RECORD = undefined;
                                        }
                                    },
                                    error: function(){
                                        message_popup( false, 2,"Błąd połączenia z REGON. Proszę zgłosić ten błąd do administratora." );
                                        validity_data.TIMES_REPEAT_IN_EDIT = undefined;
                                        validity_data.NIP_IN_EDIT = undefined;
                                        validity_data.NIP_RECORD = undefined;
                                    }
                                });
                            } else {
                                if( validity_data.NIP_IN_EDIT == document.getElementById("nip_c").value ){
                                    validity_data.TIMES_REPEAT_IN_EDIT = undefined;
                                    validity_data.NIP_IN_EDIT = undefined;
                                    validity_data.NIP_RECORD = undefined;
                                    message_popup( true, 2,"Dane kontrahentu zostały dodane do bazy danych.");
                                } else {
                                    validity_data.TIMES_REPEAT_IN_EDIT = undefined;
                                    validity_data.NIP_IN_EDIT = undefined;
                                    validity_data.NIP_RECORD = undefined;
                                    message_popup( false, 2,"Wpisałeś niepasujący NIP z takimi danych. Proszę spróbować ponownie!");
                                }
                            }
                        }
                    } else {
                        message_field(4,array_after_checked_nip["msg"]);
                    }
                } else {
                    message_field(3);
                    document.getElementById("description").value = "***Osoby fizyczne lub spolka organizacji - nie sprawdzam NIPu.";
                    save_account();
                }
            } else {
                message_field(3);
                document.getElementById("description").value = "***Firma zagraniczna - nie sprawdzam NIPu.";
                save_account();
            }
        } else {
            message_field(2);
        }
    } else {
        message_popup( false, 2, "Błąd, nie odnaleziono potrzebne pola danych. Error (1)");
    }
}

/** message_popup - Komunikaty okienka w suitecrm 
 * @param {, bool_save : bool, choice_num_popup : int, message_in_popup : string, data_from_gus : object(array), all_data : bool }
 */
function message_popup( bool_save, choice_num_popup, message_in_popup, data_from_gus, all_data){
    var form_arr = [];
    form_arr["administracja"] = "Administracja";
    form_arr["dzialalnosc_gospodarcza"] = "Działalność Gospodarcza";
    form_arr["spolka_akcyjna"] = "Sp. Akcyjna";
    form_arr["spolka_zoo"] = "Sp. z o.o.";
    form_arr["spolka_cywilna"] = "Sp. Cywilna";
    form_arr["spolka_jawna"] = "Sp. Jawna";
    form_arr["spolka_partnerska"] = "Sp. Partnerska";
    form_arr["spolka_komandytowa"] = "Sp. Komandytowa";
    form_arr["spolka_zoo_komandytowa"] = "Sp. z o.o. Komandytowa";
    form_arr["spolka_koman_akcyj"] = "Sp z Komandytowo-Akcyjna";
    form_arr["fundacja"] = "Fundacja";
    form_arr["stowarzyszenie"] = "Stowarzyszenie";
    form_arr["spolka_komandytowo_sa"] = "Sp. z o.o. Komandytowa S.A.";

    if( choice_num_popup == 1 ){
        var str = "Pobrano danych z GUS. Sprawdz poprawność danych.</br></br>";
        var pixel_height = 10;
        if(all_data){
            if(document.getElementById("name") != null){ // NAZWA 
                pixel_height += 15;
                if ( data_from_gus.nazwa != undefined ){ 
                    if( data_from_gus.nazwa != "EMPTY_DATA_FROM_GUS" ){
                        str += ("Nazwa: " + data_from_gus.nazwa + "</br>");
                    } else {
                        str += "Nazwa: -*- brak danych -*- </br>";
                    }
                } else {
                    str += "Nazwa: -*- brak danych -*- </br>";
                }
            }
            if(document.getElementById("phone_office") != null){ // TELEFON 
                pixel_height += 10;
                if ( data_from_gus.numerTelefonu != undefined ){ 
                    if( data_from_gus.numerTelefonu != "EMPTY_DATA_FROM_GUS" ){
                        str += ("Telefon: " + data_from_gus.numerTelefonu + "</br>");
                    } else {
                        str += "Telefon: -*- brak danych -*- </br>";
                    }
                } else {
                    str += "Telefon: -*- brak danych -*- </br>";
                }
            }
            if(document.getElementById("phone_fax") != null){ // FAKS
                pixel_height += 10;
                if ( data_from_gus.numerFaksu != undefined ){  
                    if( data_from_gus.numerFaksu != "EMPTY_DATA_FROM_GUS" ){
                        str += ("Faks: " + data_from_gus.numerFaksu + "</br>");
                    } else {
                        str += "Faks: -*- brak danych -*- </br>";
                    }
                } else {
                    str += "Faks: -*- brak danych -*- </br>";
                }
            }
            if(document.getElementById("account_type") != null){ // FORMA DZIAŁALNOŚCI
                pixel_height += 10;
                if ( data_from_gus.formaDzialalnosc != undefined ){  
                    if( data_from_gus.formaDzialalnosc != "EMPTY_DATA_FROM_GUS" ){
                        str += ("F.Działalności: " + form_arr[data_from_gus.formaDzialalnosc] + "</br>");
                    } else {
                        str += "F.Działalności: -*- brak danych -*- </br>";
                    }
                } else {
                    str += "F.Działalności: -*- brak danych -*- </br>";
                }
            }
            if(document.getElementById("billing_address_street") != null){ // ADRES (ULICA)
                pixel_height += 10;
                if ( data_from_gus.adres != undefined ){  
                    if( data_from_gus.adres != "EMPTY_DATA_FROM_GUS" ){
                        str += ("Ulica: " + data_from_gus.adres + "</br>");
                    } else {
                        str += "Ulica: -*- brak danych -*- </br>";
                    }
                } else {
                    str += "Ulica: -*- brak danych -*- </br>";
                }
            }
            if(document.getElementById("billing_address_city") != null){ // MIASTO
                pixel_height += 10;
                if ( data_from_gus.miasto != undefined ){  
                    if( data_from_gus.miasto != "EMPTY_DATA_FROM_GUS" ){
                        str += ("Miasto: " + data_from_gus.miasto + "</br>");
                    } else {
                        str += "Miasto: -*- brak danych -*- </br>";
                    }
                } else {
                    str += "Miasto: -*- brak danych -*- </br>";
                }
            }
            if(document.getElementById("billing_address_state") != null){ // WOJEWÓDZTWO
                pixel_height += 10;
                if ( data_from_gus.wojewodztwo != undefined ){  
                    if( data_from_gus.wojewodztwo != "EMPTY_DATA_FROM_GUS" ){
                        str += ("Województwo: " + data_from_gus.wojewodztwo + "</br>");
                    } else {
                        str += "Województwo: -*- brak danych -*- </br>";
                    }
                } else {
                    str += "Województwo: -*- brak danych -*- </br>";
                }
            }
            if(document.getElementById("billing_address_postalcode") != null){ // KOD POCZTOWY
                pixel_height += 10;
                if ( data_from_gus.kodPocztowy != undefined ){  
                    if( data_from_gus.kodPocztowy != "EMPTY_DATA_FROM_GUS" ){
                        str += ("Kod pocztowy: " + data_from_gus.kodPocztowy + "</br>");
                    } else {
                        str += "Kod pocztowy: -*- brak danych -*- </br>";
                    }
                } else {
                    str += "Kod pocztowy: -*- brak danych -*- </br>";
                }
            }
            if(document.getElementById("billing_address_country") != null){ // KRAJ
                pixel_height += 10;
                if ( data_from_gus.kraj != undefined ){  
                    if( data_from_gus.kraj != "EMPTY_DATA_FROM_GUS" ){
                        str += ("Kraj: " + data_from_gus.kraj + "</br>");
                    } else {
                        str += "Kraj: -*- brak danych -*- </br>";
                    }
                } else {
                    str += "Kraj: -*- brak danych -*- </br>";
                }
            }
            if(document.getElementById("property_number_c") != null){ // NR NIERUCHOMOŚĆI
                pixel_height += 10;
                if ( data_from_gus.numerNieruchomosci != undefined ){  
                    if( data_from_gus.numerNieruchomosci != "EMPTY_DATA_FROM_GUS" ){
                        str += ("Nr. nieruchomości: " + data_from_gus.numerNieruchomosci + "</br>");
                    } else {
                        str += "Nr. nieruchomości: -*- brak danych -*- </br>";
                    }
                } else {
                    str += "Nr. nieruchomości: -*- brak danych -*- </br>";
                }
            }
            if(document.getElementById("apartment_number_c") != null){ // NR MIESZKANIA
                pixel_height += 10;
                if ( data_from_gus.numerMieszkania != undefined ){  
                    if( data_from_gus.numerMieszkania != "EMPTY_DATA_FROM_GUS" ){
                        str += ("Nr. mieszkania: " + data_from_gus.numerMieszkania + "</br>");
                    } else {
                        str += "Nr. mieszkania: -*- brak danych -*- </br>";
                    }
                } else {
                    str += "Nr. mieszkania: -*- brak danych -*- </br>";
                }
            }
            if(document.getElementById("website") != null){ // WEBSITE
                pixel_height += 10;
                if ( data_from_gus.website != undefined ){ 
                    if( data_from_gus.website != "EMPTY_DATA_FROM_GUS" ){
                        str += ("Website: " + data_from_gus.website + "</br>");
                    } else {
                        str += "Website: -*- brak danych -*- </br>";
                    }
                } else {
                    str += "Website: -*- brak danych -*- </br>";
                }
            }
            if(document.getElementById("data_created_gus_c") != null){ // DATA POWSTANIA 
                pixel_height += 10;
                if ( data_from_gus.dataPowstania != undefined ){ 
                    if( data_from_gus.dataPowstania != "EMPTY_DATA_FROM_GUS" ){
                        str += ("Data powstania: " + data_from_gus.dataPowstania + "</br>");
                    } else {
                        str += "Data powstania: -*- brak danych -*- </br>";
                    }
                } else {
                    str += "Data powstania: -*- brak danych -*- </br>";
                }
            }
            if(document.getElementById("data_begin_activity_c") != null){ // DATA ROZPOCZĘCIA DZIAŁALNOŚCI
                pixel_height += 10;
                if ( data_from_gus.dataRozpoczeciaDzialalnosci != undefined ){  
                    if( data_from_gus.dataRozpoczeciaDzialalnosci != "EMPTY_DATA_FROM_GUS" ){
                        str += ("Data rozpoczęcia działalności: " + data_from_gus.dataRozpoczeciaDzialalnosci + "</br>");
                    } else {
                        str += "Data rozpoczęcia działalności: -*- brak danych -*- </br>";
                    }
                } else {
                    str += "Data rozpoczęcia działalności: -*- brak danych -*- </br>";
                }
            }
            if(document.getElementById("data_end_activity_c") != null){ // DATA ZAKOŃCZENIA DZIAŁALNOŚCI
                pixel_height += 10;
                if ( data_from_gus.dataZakonczeniaDzialalnosci != undefined ){  
                    if( data_from_gus.dataZakonczeniaDzialalnosci != "EMPTY_DATA_FROM_GUS" ){
                        str += ("Data zakończenia działalności: " + data_from_gus.dataZakonczeniaDzialalnosci + "</br>");
                    } else {
                        str += "Data zakończenia działalności: -*- brak danych -*- </br>";
                    }
                } else {
                    str += "Data zakończenia działalności: -*- brak danych -*- </br>";
                }
            }
            if(document.getElementById("data_created_gus_c") != null){ // DATA WZNOWIENIA DZIAŁALNOŚCI
                pixel_height += 10;
                if ( data_from_gus.dataWznowieniaDzialalnosci != undefined ){  
                    if( data_from_gus.dataWznowieniaDzialalnosci != "EMPTY_DATA_FROM_GUS" ){
                        str += ("Data wznowienia działalności: " + data_from_gus.dataWznowieniaDzialalnosci + "</br>");
                    } else {
                        str += "Data wznowienia działalności: -*- brak danych -*- </br>";
                    }
                } else {
                    str += "Data wznowienia działalności: -*- brak danych -*- </br>";
                }
            }
            if(document.getElementById("data_renewal_activity_c") != null){ // DATA ZAWIESZENIA DZIAŁALNOŚCI
                pixel_height += 10;
                if ( data_from_gus.dataZawieszeniaDzialalnosci != undefined ){  
                    if( data_from_gus.dataZawieszeniaDzialalnosci != "EMPTY_DATA_FROM_GUS" ){
                        str += ("Data zawieszenia działalności: " + data_from_gus.dataZawieszeniaDzialalnosci + "</br>");
                    } else {
                        str += "Data zawieszenia działalności: -*- brak danych -*- </br>";
                    }
                } else {
                    str += "Data zawieszenia działalności: -*- brak danych -*- </br>";
                }
            }
            if(document.getElementById("date_bankruptcy_c") != null){ // DATA ORZECZENIA O DZIAŁALNOŚCI
                pixel_height += 10;
                if ( data_from_gus.dataOrzeczeniaOUpadlosci != undefined ){  
                    if( data_from_gus.dataOrzeczeniaOUpadlosci != "EMPTY_DATA_FROM_GUS" ){
                        str += ("Data orzeczenia o upadłości: " + data_from_gus.dataOrzeczeniaOUpadlosci + "</br>");
                    } else {
                        str += "Data orzeczenia o upadłości: -*- brak danych -*- </br>";
                    }
                } else {
                    str += "Data orzeczenia o upadłości: -*- brak danych -*- </br>";
                }
            }
            if(document.getElementById("data_ending_of_bankruptcy_c") != null){ // DATA ZAKOŃCZENIA POSTĘPOWANIA UPADŁOSCIOWEGO
                pixel_height += 10;
                if ( data_from_gus.dataZakonczeniaPostepowaniaUpadlosciowego != undefined ){  
                    if( data_from_gus.dataZakonczeniaPostepowaniaUpadlosciowego != "EMPTY_DATA_FROM_GUS" ){
                        str += ("Data zakończenia postępowania upadłościowego: " + data_from_gus.dataZakonczeniaPostepowaniaUpadlosciowego + "</br>");
                    } else {
                        str += "Data zakończenia postępowania upadłościowego: -*- brak danych -*- </br>";
                    }
                } else {
                    str += "Data zakończenia postępowania upadłościowego: -*- brak danych -*- </br>";
                }
            }
        } else {
            if(document.getElementById("name") != null){ // NAZWA
                if( document.getElementById("name").value != data_from_gus.nazwa ){ 
                    if( data_from_gus.nazwa != "EMPTY_DATA_FROM_GUS" && data_from_gus.nazwa != "SAME_DATA" && data_from_gus.nazwa != undefined ){
                        str += ("Nazwa: " + data_from_gus.nazwa + "</br>");
                        pixel_height += 20;
                    } 
                }
            }
            if(document.getElementById("phone_office") != null){ // TELEFON
                if( document.getElementById("phone_office").value != data_from_gus.numerTelefonu ){ 
                    if( data_from_gus.numerTelefonu != "EMPTY_DATA_FROM_GUS" && data_from_gus.numerTelefonu != "SAME_DATA" && data_from_gus.numerTelefonu != undefined ){
                        str += ("Telefon: " + data_from_gus.numerTelefonu + "</br>");
                        pixel_height += 10;
                    }
                }
            }
            if(document.getElementById("phone_fax") != null){ // FAKS
                if( document.getElementById("phone_fax").value != data_from_gus.numerFaksu ){ 
                    if( data_from_gus.numerFaksu != "EMPTY_DATA_FROM_GUS" && data_from_gus.numerFaksu != "SAME_DATA" && data_from_gus.numerFaksu != undefined ){
                        str += ("FAKS: " + data_from_gus.numerFaksu + "</br>");
                        pixel_height += 10;
                    }
                }
            }
            if(document.getElementById("account_type") != null){ // FORMA DZIAŁALNOŚCI
                if( document.getElementById("account_type").value != data_from_gus.formaDzialalnosc ){ 
                    if( data_from_gus.formaDzialalnosc != "EMPTY_DATA_FROM_GUS" && data_from_gus.formaDzialalnosc != "SAME_DATA" && data_from_gus.formaDzialalnosc != undefined ){
                        str += ("Forma Działalność: " + form_arr[data_from_gus.formaDzialalnosc] + "</br>");
                        pixel_height += 10;
                    }
                }
            }
            if(document.getElementById("billing_address_street") != null){ // ADRES
                if( document.getElementById("billing_address_street").value != data_from_gus.adres ){ 
                    if( data_from_gus.adres != "EMPTY_DATA_FROM_GUS" && data_from_gus.adres != "SAME_DATA" && data_from_gus.adres != undefined ){
                        str += ("Ulica: " + data_from_gus.adres + "</br>");
                        pixel_height += 10;
                    }
                }
            }
            if(document.getElementById("billing_address_city") != null){ // MIASTO
                if( document.getElementById("billing_address_city").value != data_from_gus.miasto ){ 
                    if( data_from_gus.miasto != "EMPTY_DATA_FROM_GUS" && data_from_gus.miasto != "SAME_DATA" && data_from_gus.miasto != undefined ){
                        str += ("Miasto: " + data_from_gus.miasto + "</br>");
                        pixel_height += 10;
                    }
                }
            }
            if(document.getElementById("billing_address_state") != null){ // WOJEWÓDZTWO
                if( document.getElementById("billing_address_state").value != data_from_gus.wojewodztwo ){ 
                    if( data_from_gus.wojewodztwo != "EMPTY_DATA_FROM_GUS" && data_from_gus.wojewodztwo != "SAME_DATA" && data_from_gus.wojewodztwo != undefined ){
                        str += ("Województwo: " + data_from_gus.wojewodztwo + "</br>");
                        pixel_height += 10;
                    }
                }
            }
            if(document.getElementById("billing_address_postalcode") != null){ // KOD POCZTOWY
                if( document.getElementById("billing_address_postalcode").value != data_from_gus.kodPocztowy ){ 
                    if( data_from_gus.kodPocztowy != "EMPTY_DATA_FROM_GUS" && data_from_gus.kodPocztowy != "SAME_DATA" && data_from_gus.kodPocztowy != undefined ){
                        str += ("Kod pocztowy: " + data_from_gus.kodPocztowy + "</br>");
                        pixel_height += 10;
                    }
                }
            }
            if(document.getElementById("billing_address_country") != null){ // KRAJ
                if( document.getElementById("billing_address_country").value != data_from_gus.kraj ){ 
                    if( data_from_gus.kraj != "EMPTY_DATA_FROM_GUS" && data_from_gus.kraj != "SAME_DATA" && data_from_gus.kraj != undefined ){
                        str += ("Kraj: " + data_from_gus.kraj + "</br>");
                        pixel_height += 10;
                    }
                }
            }
            if(document.getElementById("property_number_c") != null){ // NR NIERUCHOMOŚCI
                if( document.getElementById("property_number_c").value != data_from_gus.numerNieruchomosci ){ 
                    if( data_from_gus.numerNieruchomosci != "EMPTY_DATA_FROM_GUS" && data_from_gus.numerNieruchomosci != "SAME_DATA" && data_from_gus.numerNieruchomosci != undefined ){
                        str += ("Nr nieruchomości: " + data_from_gus.numerNieruchomosci + "</br>");
                        pixel_height += 10;
                    }
                }
            }
            if(document.getElementById("apartment_number_c") != null){ // NR MIESZKANIA
                if( document.getElementById("apartment_number_c").value != data_from_gus.numerMieszkania ){ 
                    if( data_from_gus.numerMieszkania != "EMPTY_DATA_FROM_GUS" && data_from_gus.numerMieszkania != "SAME_DATA" && data_from_gus.numerMieszkania != undefined ){
                        str += ("Nr Mieszkania: " + data_from_gus.numerMieszkania + "</br>");
                        pixel_height += 10;
                    }
                }
            }
            if(document.getElementById("website") != null){ // WEBSITE
                if( document.getElementById("website").value != data_from_gus.website ){ 
                    if( data_from_gus.website != "EMPTY_DATA_FROM_GUS" && data_from_gus.website != "SAME_DATA" && data_from_gus.website != undefined ){
                        str += ("Website: " + data_from_gus.website + "</br>");
                        pixel_height += 10;
                    }
                }
            }
            if(document.getElementById("data_created_gus_c") != null){ // DATA POWSTANIA
                if( document.getElementById("data_created_gus_c").value != data_from_gus.dataPowstania ){ 
                    if( data_from_gus.dataPowstania != "EMPTY_DATA_FROM_GUS" && data_from_gus.dataPowstania != "SAME_DATA" && data_from_gus.dataPowstania != undefined ){
                        str += ("Data powstania: " + data_from_gus.dataPowstania + "</br>");
                        pixel_height += 10;
                    }
                }
            }
            if(document.getElementById("data_begin_activity_c") != null){ // DATA ROZPOCZĘCIA DZIAŁALNOŚCI
                if( document.getElementById("data_begin_activity_c").value != data_from_gus.dataRozpoczeciaDzialalnosci ){ 
                    if( data_from_gus.dataRozpoczeciaDzialalnosci != "EMPTY_DATA_FROM_GUS" && data_from_gus.dataRozpoczeciaDzialalnosci != "SAME_DATA" && data_from_gus.dataRozpoczeciaDzialalnosci != undefined ){
                        str += ("Data rozpoczęcia działalności : " + data_from_gus.dataRozpoczeciaDzialalnosci + "</br>");
                        pixel_height += 10;
                    }
                }
            }
            if(document.getElementById("data_end_activity_c") != null){ // DATA ZAKOŃCZENIA DZIAŁALNOŚCI
                if( document.getElementById("data_end_activity_c").value != data_from_gus.dataZakonczeniaDzialalnosci ){ 
                    if( data_from_gus.dataZakonczeniaDzialalnosci != "EMPTY_DATA_FROM_GUS" && data_from_gus.dataZakonczeniaDzialalnosci != "SAME_DATA" && data_from_gus.dataZakonczeniaDzialalnosci != undefined ){
                        str += ("Data zakończenia działalnośći: " + data_from_gus.dataZakonczeniaDzialalnosci + "</br>");
                        pixel_height += 10;
                    }
                }
            }
            if(document.getElementById("data_renewal_activity_c") != null){ // DATA WZNOWIENIA DZIAŁANOŚĆI
                if( document.getElementById("data_renewal_activity_c").value != data_from_gus.dataWznowieniaDzialalnosci ){ 
                    if( data_from_gus.dataWznowieniaDzialalnosci != "EMPTY_DATA_FROM_GUS" && data_from_gus.dataWznowieniaDzialalnosci != "SAME_DATA" && data_from_gus.dataWznowieniaDzialalnosci != undefined ){
                        str += ("Data wznowienia działalnośći: " + data_from_gus.dataWznowieniaDzialalnosci + "</br>");
                        pixel_height += 10;
                    }
                }
            }
            if(document.getElementById("data_suspension_activity_c") != null){ // DATA ZAWIESZENIA DZIAŁALNOŚCI
                if( document.getElementById("data_suspension_activity_c").value != data_from_gus.dataZawieszeniaDzialalnosci ){ 
                    if( data_from_gus.dataZawieszeniaDzialalnosci != "EMPTY_DATA_FROM_GUS" && data_from_gus.dataZawieszeniaDzialalnosci != "SAME_DATA" && data_from_gus.dataZawieszeniaDzialalnosci != undefined ){
                        str += ("Data zawieszenia działalności: " + data_from_gus.dataZawieszeniaDzialalnosci + "</br>");
                        pixel_height += 10;
                    }
                }
            }
            if(document.getElementById("date_bankruptcy_c") != null){ // DATA ORZECZENIA O UPADŁOŚCI
                if( document.getElementById("date_bankruptcy_c").value != data_from_gus.dataOrzeczeniaOUpadlosci ){ 
                    if( data_from_gus.dataOrzeczeniaOUpadlosci != "EMPTY_DATA_FROM_GUS" && data_from_gus.dataOrzeczeniaOUpadlosci != "SAME_DATA" && data_from_gus.dataOrzeczeniaOUpadlosci != undefined ){
                        str += (": " + data_from_gus.dataOrzeczeniaOUpadlosci + "</br>");
                        pixel_height += 10;
                    }
                }
            }
            if(document.getElementById("data_ending_of_bankruptcy_c") != null){ // DATA ZAKOŃCZENIA POSTĘPOWANIA UPADŁOSCIOWEGO
                if( document.getElementById("data_ending_of_bankruptcy_c").value != data_from_gus.dataZakonczeniaPostepowaniaUpadlosciowego ){ 
                    if( data_from_gus.dataZakonczeniaPostepowaniaUpadlosciowego != "EMPTY_DATA_FROM_GUS" && data_from_gus.dataZakonczeniaPostepowaniaUpadlosciowego != "SAME_DATA" && data_from_gus.dataZakonczeniaPostepowaniaUpadlosciowego != undefined ){
                        str += (": " + data_from_gus.dataZakonczeniaPostepowaniaUpadlosciowego + "</br>");
                        pixel_height += 10;
                    }
                }
            }
        }
        DialogAfterDownloadData = new YAHOO.widget.SimpleDialog("dlg",{
            xy:[650,50],
            width: "490px",
            height: pixel_height.toString()+"px",
            draggable: true,
            close: false,
            constraintoviewport : true, 
            effect:{
                effect: YAHOO.widget.ContainerEffect.FADE,
                duration: 0.25
            },
            modal: true,
            visible: false
        });
        DialogAfterDownloadData.setHeader("Informacja!");
        DialogAfterDownloadData.setBody(str);
        var handleYes = function() {
            if(all_data == true){
                clear_data(4);
                assign_data_to_suitecrm( 1, data_from_gus );
            } else {
                clear_data(2, data_from_gus);
                assign_data_to_suitecrm( 2, data_from_gus );
            }
            this.hide();
        };
        var handleNo = function() {
            this.hide();
        };
        var myButtons = [
            { text: "Zatwierdz", handler: handleYes },
            { text:"Anuluj", handler: handleNo, isDefault:true}
        ];
        DialogAfterDownloadData.cfg.queueProperty("buttons", myButtons);
        DialogAfterDownloadData.render(document.body);
        DialogAfterDownloadData.show();
    } else if( choice_num_popup == 2 ) {
        InformMessage = new YAHOO.widget.SimpleDialog("dlg",
        {
            xy:[650,50],
            width: "30em",
            height: "1em",
            draggable: false,
            close: false,
            constraintoviewport : true, 
            effect:{
                effect: YAHOO.widget.ContainerEffect.FADE,
                duration: 0.25
            },
            modal: true,
            visible: false
        });
        InformMessage.setHeader("Komunikat!");
        InformMessage.setBody(message_in_popup);
        var handleOk = function() {
            //user confirms the deletion of this item;
            //this method would perform that deletion;
            //when ready, hide the SimpleDialog:
            if(bool_save) save_account();
            this.hide();
        };
        var myButtons = [
            { text: "Ok", handler: handleOk, isDefault:true}
        ];
        InformMessage.cfg.queueProperty("buttons", myButtons);
        InformMessage.render(document.body);
        InformMessage.show();
    } 
}
function assign_data_to_suitecrm( mode, data_from_gus ){
    if( mode == 1 ){
        if( document.getElementById("name") != null ){ // NAZWA
            if( data_from_gus.nazwa != undefined ){
                if( data_from_gus.nazwa != "EMPTY_DATA_FROM_GUS" ){
                    document.getElementById("name").value = data_from_gus.nazwa;
                } 
            }
        } else {
            console.error("Nie ma elementu z id \'name\' więc nie przypisano tej zmiennej do suitecrm");
        }
        if( document.getElementById("phone_office") != null ){ // NR TELEFONU
            if( data_from_gus.numerTelefonu != undefined ){
                if( data_from_gus.numerTelefonu != "EMPTY_DATA_FROM_GUS" ){
                    document.getElementById("phone_office").value = data_from_gus.numerTelefonu;
                } 
            }
        } else {
            console.error("Nie ma elementu z id \'phone_office\' więc nie przypisano tej zmiennej do suitecrm");
        }
        if( document.getElementById("phone_fax") != null ){ // FAKS
            if( data_from_gus.numerFaksu != undefined ){
                if( data_from_gus.numerFaksu != "EMPTY_DATA_FROM_GUS" ){
                    document.getElementById("phone_fax").value = data_from_gus.numerFaksu;
                } 
            }
        } else {
            console.error("Nie ma elementu z id \'phone_fax\' więc nie przypisano tej zmiennej do suitecrm");
        }
        if( document.getElementById("account_type") != null ){ // FORMA DZIAŁALNOŚCI
            if( data_from_gus.formaDzialalnosc  != undefined ){
                if( data_from_gus.formaDzialalnosc  != "EMPTY_DATA_FROM_GUS" ){
                    document.getElementById("account_type").value = data_from_gus.formaDzialalnosc ;
                } 
            }
        } else {
            console.error("Nie ma elementu z id \'account_type\' więc nie przypisano tej zmiennej do suitecrm");
        }
        if( document.getElementById("billing_address_street") != null ){ // ADRES
            if( data_from_gus.adres != undefined ){
                if( data_from_gus.adres != "EMPTY_DATA_FROM_GUS" ){
                    document.getElementById("billing_address_street").value = data_from_gus.adres;
                } 
            }
        } else {
            console.error("Nie ma elementu z id \'billing_address_street\' więc nie przypisano tej zmiennej do suitecrm");
        }
        if( document.getElementById("billing_address_city") != null ){ // MIASTO
            if( data_from_gus.miasto  != undefined ){
                if( data_from_gus.miasto  != "EMPTY_DATA_FROM_GUS" ){
                    document.getElementById("billing_address_city").value = data_from_gus.miasto;
                } 
            }
        } else {
            console.error("Nie ma elementu z id \'billing_address_city\' więc nie przypisano tej zmiennej do suitecrm");
        }
        if( document.getElementById("billing_address_state") != null ){ // WOJEWÓDZTWO
            if( data_from_gus.wojewodztwo != undefined ){
                if( data_from_gus.wojewodztwo  != "EMPTY_DATA_FROM_GUS" ){
                    document.getElementById("billing_address_state").value = data_from_gus.wojewodztwo;
                } 
            }
        } else {
            console.error("Nie ma elementu z id \'billing_address_state\' więc nie przypisano tej zmiennej do suitecrm");
        }
        if( document.getElementById("billing_address_postalcode") != null ){ // KOD POCZTOWY
            if( data_from_gus.kodPocztowy  != undefined ){
                if( data_from_gus.kodPocztowy  != "EMPTY_DATA_FROM_GUS" ){
                    document.getElementById("billing_address_postalcode").value = data_from_gus.kodPocztowy;
                } 
            }
        } else {
            console.error("Nie ma elementu z id \'billing_address_postalcode\' więc nie przypisano tej zmiennej do suitecrm");
        }
        if( document.getElementById("billing_address_country") != null ){ // KRAJ
            if( data_from_gus.kraj != undefined ){
                if( data_from_gus.kraj != "EMPTY_DATA_FROM_GUS" ){
                    document.getElementById("billing_address_country").value = data_from_gus.kraj;
                } 
            }
        } else {
            console.error("Nie ma elementu z id \'billing_address_country\' więc nie przypisano tej zmiennej do suitecrm");
        }
        if( document.getElementById("property_number_c") != null ){ // NR NIERUCHOMOŚCI
            if( data_from_gus.numerNieruchomosci != undefined ){
                if( data_from_gus.numerNieruchomosci != "EMPTY_DATA_FROM_GUS" ){
                    document.getElementById("property_number_c").value = data_from_gus.numerNieruchomosci;
                } 
            }
        } else {
            console.error("Nie ma elementu z id \'property_number_c\' więc nie przypisano tej zmiennej do suitecrm");
        }
        if( document.getElementById("apartment_number_c") != null ){ // NR MIESZKANIA
            if( data_from_gus.numerMieszkania  != undefined ){
                if( data_from_gus.numerMieszkania  != "EMPTY_DATA_FROM_GUS" ){
                    document.getElementById("apartment_number_c").value = data_from_gus.numerMieszkania ;
                } 
            }
        } else {
            console.error("Nie ma elementu z id \'apartment_number_c\' więc nie przypisano tej zmiennej do suitecrm");
        }
        if( document.getElementById("website") != null ){ // WEBSITE
            if( data_from_gus.website != undefined ){
                if( data_from_gus.website != "EMPTY_DATA_FROM_GUS" ){
                    document.getElementById("website").value = data_from_gus.website;
                } else {
                    document.getElementById("website").value = "http://";
                }
            }
        } else {
            console.error("Nie ma elementu z id \'website\' więc nie przypisano tej zmiennej do suitecrm");
        }
        if( document.getElementById("data_created_gus_c") != null ){ // DATA POWSTANIA
            if( data_from_gus.dataPowstania  != undefined ){
                if( data_from_gus.dataPowstania  != "EMPTY_DATA_FROM_GUS" ){
                    document.getElementById("data_created_gus_c").value = data_from_gus.dataPowstania ;
                } 
            }
        } else {
            console.error("Nie ma elementu z id \'data_created_gus_c\' więc nie przypisano tej zmiennej do suitecrm");
        }
        if( document.getElementById("data_begin_activity_c") != null ){ // DATA ROZPOCZĘCIA DZIAŁALNOŚCI
            if( data_from_gus.dataRozpoczeciaDzialalnosci != undefined ){
                if( data_from_gus.dataRozpoczeciaDzialalnosci != "EMPTY_DATA_FROM_GUS" ){
                    document.getElementById("data_begin_activity_c").value = data_from_gus.dataRozpoczeciaDzialalnosci;
                } 
            }
        } else {
            console.error("Nie ma elementu z id \'data_begin_activity_c\' więc nie przypisano tej zmiennej do suitecrm");
        }
        if( document.getElementById("data_end_activity_c") != null ){ // DATA ZAKOŃCZENIA DZIAŁALNOŚCI
            if( data_from_gus.dataZakonczeniaDzialalnosci != undefined ){
                if( data_from_gus.dataZakonczeniaDzialalnosci != "EMPTY_DATA_FROM_GUS" ){
                    document.getElementById("data_end_activity_c").value = data_from_gus.dataZakonczeniaDzialalnosci;
                } 
            }
        } else {
            console.error("Nie ma elementu z id \'data_end_activity_c\' więc nie przypisano tej zmiennej do suitecrm");
        }
        if( document.getElementById("data_renewal_activity_c") != null ){ // DATA WZNOWIENIA DZIAŁALNOŚCI
            if( data_from_gus.dataWznowieniaDzialalnosci  != undefined ){
                if( data_from_gus.dataWznowieniaDzialalnosci  != "EMPTY_DATA_FROM_GUS" ){
                    document.getElementById("data_renewal_activity_c").value = data_from_gus.dataWznowieniaDzialalnosci ;
                } 
            }
        } else {
            console.error("Nie ma elementu z id \'data_renewal_activity_c\' więc nie przypisano tej zmiennej do suitecrm");
        }
        if( document.getElementById("data_suspension_activity_c") != null ){ // DATA ZAWIESZENIA DZIAŁALNOŚCI
            if( data_from_gus.dataZawieszeniaDzialalnosci  != undefined ){
                if( data_from_gus.dataZawieszeniaDzialalnosci  != "EMPTY_DATA_FROM_GUS" ){
                    document.getElementById("data_suspension_activity_c").value = data_from_gus.dataZawieszeniaDzialalnosci ;
                } 
            }
        } else {
            console.error("Nie ma elementu z id \'data_suspension_activity_c\' więc nie przypisano tej zmiennej do suitecrm");
        }
        if( document.getElementById("date_bankruptcy_c") != null ){ // DATA ORZECZENIA O UPADŁOŚCI
            if( data_from_gus.dataOrzeczeniaOUpadlosci  != undefined ){
                if( data_from_gus.dataOrzeczeniaOUpadlosci  != "EMPTY_DATA_FROM_GUS" ){
                    document.getElementById("date_bankruptcy_c").value = data_from_gus.dataOrzeczeniaOUpadlosci ;
                } 
            }
        } else {
            console.error("Nie ma elementu z id \'date_bankruptcy_c\' więc nie przypisano tej zmiennej do suitecrm");
        }
        if( document.getElementById("data_ending_of_bankruptcy_c") != null ){ // DATA ZAKOŃCZENIA POSTĘPOWANIA UPADŁOSCIOWEGO
            if( data_from_gus.dataZakonczeniaPostepowaniaUpadlosciowego  != undefined ){
                if( data_from_gus.dataZakonczeniaPostepowaniaUpadlosciowego  != "EMPTY_DATA_FROM_GUS" ){
                    document.getElementById("data_ending_of_bankruptcy_c").value = data_from_gus.dataZakonczeniaPostepowaniaUpadlosciowego ;
                } 
            }
        } else {
            console.error("Nie ma elementu z id \'data_ending_of_bankruptcy_c\' więc nie przypisano tej zmiennej do suitecrm");
        }
    } else {
        if(document.getElementById("name") != null){ // NAZWA
            if( data_from_gus.nazwa != "EMPTY_DATA_FROM_GUS" && data_from_gus.nazwa != "SAME_DATA" && data_from_gus.nazwa != undefined ){
                document.getElementById("name").value = data_from_gus.nazwa;
            }
        } else {
            console.error("Nie ma elementu z id \'name\' więc nie przypisano tej zmiennej do suitecrm");
        }
        if(document.getElementById("phone_office") != null){ // TELEFON
            if( document.getElementById("phone_office").value != data_from_gus.numerTelefonu ){
                if( data_from_gus.numerTelefonu != "EMPTY_DATA_FROM_GUS" && data_from_gus.numerTelefonu != "SAME_DATA" && data_from_gus.numerTelefonu != undefined ){
                    document.getElementById("phone_office").value = data_from_gus.numerTelefonu;
                }
            }
        } else {
            console.error("Nie ma elementu z id \'phone_office\' więc nie przypisano tej zmiennej do suitecrm");
        }
        if(document.getElementById("phone_fax") != null){ // FAKS
            if( document.getElementById("phone_fax").value != data_from_gus.numerFaksu ){
                if( data_from_gus.numerFaksu != "EMPTY_DATA_FROM_GUS" && data_from_gus.numerFaksu != "SAME_DATA" && data_from_gus.numerFaksu != undefined ){
                    document.getElementById("phone_fax").value = data_from_gus.numerFaksu;
                }
            }
        } else {
            console.error("Nie ma elementu z id \'phone_fax\' więc nie przypisano tej zmiennej do suitecrm");
        }
        if(document.getElementById("account_type") != null){ // FORMA DZIAŁALNOŚCI
            if( document.getElementById("account_type").value != data_from_gus.formaDzialalnosc ){
                if( data_from_gus.formaDzialalnosc != "EMPTY_DATA_FROM_GUS" && data_from_gus.formaDzialalnosc != "SAME_DATA" && data_from_gus.formaDzialalnosc != undefined ){
                    document.getElementById("account_type").value = data_from_gus.formaDzialalnosc;
                }
            }
        } else {
            console.error("Nie ma elementu z id \'account_type\' więc nie przypisano tej zmiennej do suitecrm");
        }
        if(document.getElementById("billing_address_street") != null){ // ADRES
            if( document.getElementById("billing_address_street").value != data_from_gus.adres ){
                if( data_from_gus.adres != "EMPTY_DATA_FROM_GUS" && data_from_gus.adres != "SAME_DATA" && data_from_gus.adres != undefined ){
                    document.getElementById("billing_address_street").value = data_from_gus.adres;
                }
            }
        } else {
            console.error("Nie ma elementu z id \'billing_address_street\' więc nie przypisano tej zmiennej do suitecrm");
        }
        if(document.getElementById("billing_address_city") != null){ // MIASTO
            if( document.getElementById("billing_address_city").value != data_from_gus.miasto ){
                if( data_from_gus.miasto != "EMPTY_DATA_FROM_GUS" && data_from_gus.miasto != "SAME_DATA" && data_from_gus.miasto != undefined ){
                    document.getElementById("billing_address_city").value = data_from_gus.miasto;
                }
            }
        } else {
            console.error("Nie ma elementu z id \'billing_address_city\' więc nie przypisano tej zmiennej do suitecrm");
        }
        if(document.getElementById("billing_address_state") != null){ // WOJEWÓDZTWO
            if( document.getElementById("billing_address_state").value != data_from_gus.wojewodztwo ){
                if( data_from_gus.wojewodztwo != "EMPTY_DATA_FROM_GUS" && data_from_gus.wojewodztwo != "SAME_DATA" && data_from_gus.wojewodztwo != undefined ){
                    document.getElementById("billing_address_state").value = data_from_gus.wojewodztwo;
                }
            }
        } else {
            console.error("Nie ma elementu z id \'billing_address_state\' więc nie przypisano tej zmiennej do suitecrm");
        }
        if(document.getElementById("billing_address_postalcode") != null){ // KOD POCZTOWY
            if( document.getElementById("billing_address_postalcode").value != data_from_gus.kodPocztowy ){
                if( data_from_gus.kodPocztowy != "EMPTY_DATA_FROM_GUS" && data_from_gus.kodPocztowy != "SAME_DATA" && data_from_gus.kodPocztowy != undefined ){
                    document.getElementById("billing_address_postalcode").value = data_from_gus.kodPocztowy;
                }
            }
        } else {
            console.error("Nie ma elementu z id \'billing_address_postalcode\' więc nie przypisano tej zmiennej do suitecrm");
        }
        if(document.getElementById("billing_address_country") != null){ // KRAJ
            if( document.getElementById("billing_address_country").value != data_from_gus.kraj ){
                if( data_from_gus.kraj != "EMPTY_DATA_FROM_GUS" && data_from_gus.kraj != "SAME_DATA" && data_from_gus.kraj != undefined ){
                    document.getElementById("billing_address_country").value = data_from_gus.kraj;
                }
            }
        } else {
            console.error("Nie ma elementu z id \'billing_address_postalcode\' więc nie przypisano tej zmiennej do suitecrm");
        }
        if(document.getElementById("property_number_c") != null){ // NR NIERUCHOMOŚCI
            if( document.getElementById("property_number_c").value != data_from_gus.numerNieruchomosci ){
                if( data_from_gus.numerNieruchomosci != "EMPTY_DATA_FROM_GUS" && data_from_gus.numerNieruchomosci != "SAME_DATA" && data_from_gus.numerNieruchomosci != undefined ){
                    document.getElementById("property_number_c").value = data_from_gus.numerNieruchomosci;
                }
            }
        } else {
            console.error("Nie ma elementu z id \'name\' więc nie przypisano tej zmiennej do suitecrm");
        }
        if(document.getElementById("apartment_number_c") != null){ // NR MIESZKANIA
            if( document.getElementById("apartment_number_c").value != data_from_gus.numerMieszkania ){
                if( data_from_gus.numerMieszkania != "EMPTY_DATA_FROM_GUS" && data_from_gus.numerMieszkania != "SAME_DATA" && data_from_gus.numerMieszkania != undefined ){
                    document.getElementById("apartment_number_c").value = data_from_gus.numerMieszkania;
                }
            }
        } else {
            console.error("Nie ma elementu z id \'apartment_number_c\' więc nie przypisano tej zmiennej do suitecrm");
        }
        if(document.getElementById("website") != null){ // WEBSITE
            if( document.getElementById("website").value != data_from_gus.website ){
                if(data_from_gus.website != "SAME_DATA" && data_from_gus.website != undefined ){
                    if(data_from_gus.website != "EMPTY_DATA_FROM_GUS"){
                        document.getElementById("website").value = data_from_gus.website;
                    } else {
                        document.getElementById("website").value = "http://";
                    }
                }
            }
        } else {
            console.error("Nie ma elementu z id \'website\' więc nie przypisano tej zmiennej do suitecrm");
        }
        if(document.getElementById("data_created_gus_c") != null){ // DATA POWSTANIA
            if( document.getElementById("data_created_gus_c").value != data_from_gus.dataPowstania ){
                if( data_from_gus.dataPowstania != "EMPTY_DATA_FROM_GUS" && data_from_gus.dataPowstania != "SAME_DATA" && data_from_gus.dataPowstania != undefined ){
                    document.getElementById("data_created_gus_c").value = data_from_gus.dataPowstania;
                }
            }
        } else {
            console.error("Nie ma elementu z id \'data_created_gus_c\' więc nie przypisano tej zmiennej do suitecrm");
        }
        if(document.getElementById("data_begin_activity_c") != null){ // DATA ROZPOCZĘCIA DZIAŁALNOŚCI
            if( document.getElementById("data_begin_activity_c").value != data_from_gus.dataRozpoczeciaDzialalnosci ){
                if( data_from_gus.dataRozpoczeciaDzialalnosci != "EMPTY_DATA_FROM_GUS" && data_from_gus.dataRozpoczeciaDzialalnosci != "SAME_DATA" && data_from_gus.dataRozpoczeciaDzialalnosci != undefined ){
                    document.getElementById("data_begin_activity_c").value = data_from_gus.dataRozpoczeciaDzialalnosci;
                }
            }
        } else {
            console.error("Nie ma elementu z id \'data_begin_activity_c\' więc nie przypisano tej zmiennej do suitecrm");
        }
        if(document.getElementById("data_end_activity_c") != null){ // DATA ZAKOŃCZENIA DZIAŁALNOŚCI
            if( document.getElementById("data_end_activity_c").value != data_from_gus.dataZakonczeniaDzialalnosci ){
                if( data_from_gus.dataZakonczeniaDzialalnosci != "EMPTY_DATA_FROM_GUS" && data_from_gus.dataZakonczeniaDzialalnosci != "SAME_DATA" && data_from_gus.dataZakonczeniaDzialalnosci != undefined ){
                    document.getElementById("data_end_activity_c").value = data_from_gus.dataZakonczeniaDzialalnosci;
                }
            }
        } else {
            console.error("Nie ma elementu z id \'data_end_activity_c\' więc nie przypisano tej zmiennej do suitecrm");
        }
        if(document.getElementById("data_renewal_activity_c") != null){ // DATA WZNOWIENIA DZIAŁALNOŚCI
            if( document.getElementById("data_renewal_activity_c").value != data_from_gus.dataWznowieniaDzialalnosci ){
                if( data_from_gus.dataWznowieniaDzialalnosci != "EMPTY_DATA_FROM_GUS" && data_from_gus.dataWznowieniaDzialalnosci != "SAME_DATA" && data_from_gus.dataWznowieniaDzialalnosci != undefined ){
                    document.getElementById("data_renewal_activity_c").value = data_from_gus.dataWznowieniaDzialalnosci;
                }
            }
        } else {
            console.error("Nie ma elementu z id \'data_renewal_activity_c\' więc nie przypisano tej zmiennej do suitecrm");
        }
        if(document.getElementById("data_suspension_activity_c") != null){ // DATA ZAWIESZENIA DZIAŁALNOŚCI
            if( document.getElementById("data_suspension_activity_c").value != data_from_gus.dataZawieszeniaDzialalnosci ){
                if( data_from_gus.dataZawieszeniaDzialalnosci != "EMPTY_DATA_FROM_GUS" && data_from_gus.dataZawieszeniaDzialalnosci != "SAME_DATA" && data_from_gus.dataZawieszeniaDzialalnosci != undefined ){
                    document.getElementById("data_suspension_activity_c").value = data_from_gus.dataZawieszeniaDzialalnosci;
                }
            }
        } else {
            console.error("Nie ma elementu z id \'name\' więc nie przypisano tej zmiennej do suitecrm");
        }
        if(document.getElementById("date_bankruptcy_c") != null){ // DATA ORZECZENIA O UPADŁOŚCI
            if( document.getElementById("date_bankruptcy_c").value != data_from_gus.dataOrzeczeniaOUpadlosci ){
                if( data_from_gus.dataOrzeczeniaOUpadlosci != "EMPTY_DATA_FROM_GUS" && data_from_gus.dataOrzeczeniaOUpadlosci != "SAME_DATA" && data_from_gus.dataOrzeczeniaOUpadlosci != undefined ){
                    document.getElementById("date_bankruptcy_c").value = data_from_gus.dataOrzeczeniaOUpadlosci;
                }
            }
        } else {
            console.error("Nie ma elementu z id \'date_bankruptcy_c\' więc nie przypisano tej zmiennej do suitecrm");
        }
        if(document.getElementById("data_ending_of_bankruptcy_c") != null){ // DATA ZAKOŃCZENIA POSTĘPOWANIA UPADŁOSCIOWEGO
            if( document.getElementById("data_ending_of_bankruptcy_c").value != data_from_gus.dataZakonczeniaPostepowaniaUpadlosciowego ){
                if( data_from_gus.dataZakonczeniaPostepowaniaUpadlosciowego != "EMPTY_DATA_FROM_GUS" && data_from_gus.dataZakonczeniaPostepowaniaUpadlosciowego != "SAME_DATA" && data_from_gus.dataZakonczeniaPostepowaniaUpadlosciowego != undefined ){
                    document.getElementById("data_ending_of_bankruptcy_c").value = data_from_gus.dataZakonczeniaPostepowaniaUpadlosciowego;
                }
            }
        } else {
            console.error("Nie ma elementu z id \'data_ending_of_bankruptcy_c\' więc nie przypisano tej zmiennej do suitecrm");
        }
    }
}
function clear_data( num_choice_in_clear_data,data,id_element ){
    if( num_choice_in_clear_data == 1 ) { // ALL DATA 
        document.getElementById("name").value="";
        document.getElementById("nip_c").value="";        
        document.getElementById("account_type").value="-czysto-";
        document.getElementById("typ_firmy_c").value="-czysto-";
       
        if(document.getElementById("phone_office") != null ) document.getElementById("phone_office").value="";
        if(document.getElementById("phone_fax") != null ) document.getElementById("phone_fax").value="";
        if(document.getElementById("industry") != null ) document.getElementById("industry").value="-czysto-";
        if(document.getElementById("aktywna_c") != null ) document.getElementById("aktywna_c").checked = true;
        if(document.getElementById("fforeign_c") != null ) document.getElementById("fforeign_c").checked = false;
        if(document.getElementById("description") != null ) document.getElementById("description").value = "";
        if(document.getElementById("tagi_c_tag") != null ) document.getElementById("tagi_c_tag").value = "";
        //-------------------------------
        if(document.getElementById("billing_address_street") != null ) document.getElementById("billing_address_street").value = "";
        if(document.getElementById("billing_address_city") != null ) document.getElementById("billing_address_city").value = "";
        if(document.getElementById("billing_address_state") != null ) document.getElementById("billing_address_state").value = "";
        if(document.getElementById("billing_address_postalcode") != null ) document.getElementById("billing_address_postalcode").value = "";
        if(document.getElementById("billing_address_country") != null ) document.getElementById("billing_address_country").value = "";
        if(document.getElementById("apartment_number_c") != null ) document.getElementById("apartment_number_c").value = "";
        if(document.getElementById("property_number_c") != null ) document.getElementById("property_number_c").value = "";
        if(document.getElementById("website") != null ) document.getElementById("website").value = "http://";
        //-------------------------------
        if(document.getElementById("data_created_gus_c") != null ) document.getElementById("data_created_gus_c").value = "";
        if(document.getElementById("data_begin_activity_c") != null ) document.getElementById("data_begin_activity_c").value = "";
        if(document.getElementById("data_end_activity_c") != null ) document.getElementById("data_end_activity_c").value = "";
        if(document.getElementById("data_renewal_activity_c") != null ) document.getElementById("data_renewal_activity_c").value = "";
        if(document.getElementById("data_suspension_activity_c") != null ) document.getElementById("data_suspension_activity_c").value = "";
        if(document.getElementById("date_bankruptcy_c") != null ) document.getElementById("date_bankruptcy_c").value = "";
        if(document.getElementById("data_ending_of_bankruptcy_c") != null ) document.getElementById("data_ending_of_bankruptcy_c").value = "";
    } else if( num_choice_in_clear_data == 2 ) { // SOME DATA
        if(data.nazwa == "EMPTY_DATA_FROM_GUS"){ // NAZWA
            document.getElementById("name").value = "";
        }
        if(data.formaDzialalnosc == "EMPTY_DATA_FROM_GUS"){ // FORMA DZIAŁALNOŚĆ 
            document.getElementById("account_type").value = "";
        }

        if(document.getElementById("phone_office") != null ){
            if(data.numerTelefonu == "EMPTY_DATA_FROM_GUS"){ // TELEFON
                document.getElementById("phone_office").value = "";
            }
        }
        if(document.getElementById("phone_fax") != null ){
            if(data.numerFaksu == "EMPTY_DATA_FROM_GUS"){ // FAKS
                document.getElementById("phone_fax").value = "";
            }
        }
        if(document.getElementById("billing_address_street") != null ){
            if(data.adres == "EMPTY_DATA_FROM_GUS"){ // ADRES (ulica)
                document.getElementById("billing_address_street").value = "";
            }
        }
        if(document.getElementById("billing_address_city") != null ){
            if(data.miasto == "EMPTY_DATA_FROM_GUS"){ // MIASTO
                document.getElementById("billing_address_city").value = "";
            }
        }
        if(document.getElementById("billing_address_state") != null ){
            if(data.wojewodztwo == "EMPTY_DATA_FROM_GUS"){ // WOJWEÓDZTWO
                document.getElementById("billing_address_state").value = "";
            }
        }
        if(document.getElementById("billing_address_postalcode") != null ){
            if(data.kodPocztowy == "EMPTY_DATA_FROM_GUS"){ // KOD POCZTOWY
                document.getElementById("billing_address_postalcode").value = "";
            }
        }
        if(document.getElementById("billing_address_country") != null ){
            if(data.kraj == "EMPTY_DATA_FROM_GUS"){ // KRAJ
                document.getElementById("billing_address_country").value = "";
            }
        }
        if(document.getElementById("property_number_c") != null ){
            if(data.numerNieruchomosci == "EMPTY_DATA_FROM_GUS"){ // NR NIERUCHOMOŚCI
                document.getElementById("property_number_c").value = "";
            }
        }
        if(document.getElementById("apartment_number_c") != null ){
            if(data.numerMieszkania == "EMPTY_DATA_FROM_GUS"){ // NR MIESZKANIA
                document.getElementById("apartment_number_c").value = "";
            }
        }
        if(document.getElementById("website") != null ){
            if(data.website == "EMPTY_DATA_FROM_GUS"){ // WEBSITE
                document.getElementById("website").value = "http://";
            }
        }
        if(document.getElementById("data_created_gus_c") != null ){
            if(data.dataPowstania == "EMPTY_DATA_FROM_GUS"){ // DATA POWSTANIA 
                document.getElementById("data_created_gus_c").value = "";
            }
        }
        if(document.getElementById("data_begin_activity_c") != null ){
            if(data.dataRozpoczeciaDzialalnosci == "EMPTY_DATA_FROM_GUS"){ // DATA ROZPOCZĘCIA DZIAŁALNOŚCI
                document.getElementById("data_begin_activity_c").value = "";
            }
        }
        if(document.getElementById("data_end_activity_c") != null ){
            if(data.dataZakonczeniaDzialalnosci == "EMPTY_DATA_FROM_GUS"){ // DATA ZAKONCZENIA DZIAŁALNOŚCI
                document.getElementById("data_end_activity_c").value = "";
            }
        }
        if(document.getElementById("data_renewal_activity_c") != null ){
            if(data.dataWznowieniaDzialalnosci == "EMPTY_DATA_FROM_GUS"){ // DATA WZNOWIENIA DZIAŁALNOŚCI 
                document.getElementById("data_renewal_activity_c").value = "";
            }
        }
        if(document.getElementById("data_suspension_activity_c") != null ){
            if(data.dataZawieszeniaDzialalnosci == "EMPTY_DATA_FROM_GUS"){ // DATA ZAWIESZENIA DZIAŁALNOŚCI
                document.getElementById("data_suspension_activity_c").value = "";
            }
        }
        if(document.getElementById("date_bankruptcy_c") != null ){
            if(data.dataOrzeczeniaOUpadlosci == "EMPTY_DATA_FROM_GUS"){ // DATA ORZECZENIA DZIAŁALNOŚCI
                document.getElementById("date_bankruptcy_c").value = "";
            }
        }
        if(document.getElementById("data_ending_of_bankruptcy_c") != null ){
            if(data.dataZakonczeniaPostepowaniaUpadlosciowego == "EMPTY_DATA_FROM_GUS"){ // DATA ZAKOŃCZENIA POSTĘPOWANIA UPADŁOŚCIOWEGO
                document.getElementById("data_ending_of_bankruptcy_c").value = "";
            }
        }
    } else if( num_choice_in_clear_data == 3 ) { // DESCRIPTION
        if(document.getElementById("description") != null ) document.getElementById("description").value = "";
    } else if( num_choice_in_clear_data == 4 ) { // WITHOUT NIP,TYP FIRMY,NAZWA,FORMA DZIAŁALNOŚCI
        if(document.getElementById("phone_office") != null ) document.getElementById("phone_office").value="";
        if(document.getElementById("phone_fax") != null ) document.getElementById("phone_fax").value="";
        if(document.getElementById("industry") != null ) document.getElementById("industry").value="-czysto-";
        if(document.getElementById("aktywna_c") != null ) document.getElementById("aktywna_c").checked = true;
        if(document.getElementById("fforeign_c") != null ) document.getElementById("fforeign_c").checked = false;
        if(document.getElementById("description") != null ) document.getElementById("description").value = "";
        if(document.getElementById("tagi_c_tag") != null ) document.getElementById("tagi_c_tag").value = "";
        //-------------------------------
        if(document.getElementById("billing_address_street") != null ) document.getElementById("billing_address_street").value = "";
        if(document.getElementById("billing_address_city") != null ) document.getElementById("billing_address_city").value = "";
        if(document.getElementById("billing_address_state") != null ) document.getElementById("billing_address_state").value = "";
        if(document.getElementById("billing_address_postalcode") != null ) document.getElementById("billing_address_postalcode").value = "";
        if(document.getElementById("billing_address_country") != null ) document.getElementById("billing_address_country").value = "";
        if(document.getElementById("apartment_number_c") != null ) document.getElementById("apartment_number_c").value = "";
        if(document.getElementById("property_number_c") != null ) document.getElementById("property_number_c").value = "";
        if(document.getElementById("website") != null ) document.getElementById("website").value = "http://";
        //-------------------------------
        if(document.getElementById("data_created_gus_c") != null ) document.getElementById("data_created_gus_c").value = "";
        if(document.getElementById("data_begin_activity_c") != null ) document.getElementById("data_begin_activity_c").value = "";
        if(document.getElementById("data_end_activity_c") != null ) document.getElementById("data_end_activity_c").value = "";
        if(document.getElementById("data_renewal_activity_c") != null ) document.getElementById("data_renewal_activity_c").value = "";
        if(document.getElementById("data_suspension_activity_c") != null ) document.getElementById("data_suspension_activity_c").value = "";
        if(document.getElementById("date_bankruptcy_c") != null ) document.getElementById("date_bankruptcy_c").value = "";
        if(document.getElementById("data_ending_of_bankruptcy_c") != null ) document.getElementById("data_ending_of_bankruptcy_c").value = "";
    } else if( num_choice_in_clear_data == 5 ) { // Konkretny element
        document.getElementById(id_element).value="";
    }
}

